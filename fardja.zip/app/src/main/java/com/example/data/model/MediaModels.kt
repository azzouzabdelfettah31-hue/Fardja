package com.example.data.model

enum class MediaType {
    MOVIE,
    SERIES,
    SHORT_FILM,
    SHORT_DRAMA
}

data class Episode(
    val id: String,
    val episodeNumber: Int,
    val titleAr: String,
    val titleEn: String,
    val duration: String,
    val videoUrl: String,
    val thumbnail: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val isVipOnly: Boolean = false,
    val requiresAdToUnlock: Boolean = false
)

data class MediaItem(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val originalTitle: String,
    val type: MediaType,
    val descriptionAr: String,
    val descriptionEn: String,
    val posterUrl: String,
    val backdropUrl: String,
    val videoStreamUrl: String,
    val durationText: String,
    val releaseYear: Int,
    val rating: Double,
    val ageRating: String, // "+13", "+16", "العائلة"
    val genreAr: String,
    val genreEn: String,
    val cast: List<String>,
    val director: String,
    val isVipOnly: Boolean = false,
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false,
    val trendingRank: Int = 0,
    val episodes: List<Episode> = emptyList(),
    val matchPercentage: Int = 98,
    val viewCount: String = "1.2M",
    val tags: List<String> = emptyList(),
    val isVerticalFormat: Boolean = false
)

data class CommentItem(
    val id: String,
    val authorName: String,
    val avatarUrl: String = "",
    val text: String,
    val rating: Float,
    val timestamp: String,
    val isVip: Boolean = false,
    val likes: Int = 0,
    val isLikedByMe: Boolean = false
)

data class SubscriptionPlan(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val priceAr: String,
    val priceEn: String,
    val periodAr: String,
    val periodEn: String,
    val featuresAr: List<String>,
    val featuresEn: List<String>,
    val isRecommended: Boolean = false,
    val badgeAr: String = "",
    val badgeEn: String = ""
)

data class NotificationModel(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val bodyAr: String,
    val bodyEn: String,
    val timeAgoAr: String,
    val timeAgoEn: String,
    val isUnread: Boolean = true,
    val type: String = "RELEASE", // RELEASE, PROMO, SYSTEM
    val targetMediaId: String? = null
)

data class SupportMessage(
    val id: String,
    val senderName: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: String
)

data class UserAccount(
    val uid: String = "user_fardja_719",
    val email: String = "ilyasrahal98@gmail.com",
    val displayName: String = "إلياس رحال",
    val photoUrl: String? = null,
    val isAnonymous: Boolean = false,
    val authProvider: String = "Google Account",
    val isVip: Boolean = false,
    val vipPlanName: String = "الحساب المجاني",
    val vipExpiry: String = "غير مفعل",
    val cloudProjectId: String = "fardja-719bf",
    val syncStatus: String = "متزامن ومشفر بـ AES-256",
    val lastSyncTime: String = "الآن",
    val selectedLanguage: String = "ar", // "ar" or "en"
    val isEyeComfortMode: Boolean = false,
    val favoriteGenres: Set<String> = setOf("دراما", "أكشن", "خيال علمي")
)
