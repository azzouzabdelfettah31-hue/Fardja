package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloaded_media")
data class DownloadEntity(
    @PrimaryKey
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val mediaType: String, // MOVIE, SERIES, SHORT_FILM
    val streamUrl: String,
    val localUri: String,
    val durationText: String,
    val posterUrl: String,
    val fileSizeMb: Double,
    val downloadedAt: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = true
)
