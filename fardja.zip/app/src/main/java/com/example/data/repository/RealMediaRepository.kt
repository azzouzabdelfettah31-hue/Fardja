package com.example.data.repository

import com.example.data.model.CommentItem
import com.example.data.model.Episode
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.data.model.NotificationModel
import com.example.data.model.SubscriptionPlan
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

class RealMediaRepository {

    private val _mediaItems = MutableStateFlow<List<MediaItem>>(initialMedia)
    val mediaItems = _mediaItems.asStateFlow()

    private val _comments = MutableStateFlow<Map<String, List<CommentItem>>>(initialComments)
    val comments = _comments.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationModel>>(initialNotifications)
    val notifications = _notifications.asStateFlow()

    fun getMediaById(id: String): MediaItem? {
        return _mediaItems.value.find { it.id == id }
    }

    fun getCommentsForMedia(mediaId: String): Flow<List<CommentItem>> {
        return _comments.map { map -> map[mediaId] ?: defaultSampleComments }
    }

    fun addComment(mediaId: String, comment: CommentItem) {
        val currentMap = _comments.value.toMutableMap()
        val list = (currentMap[mediaId] ?: defaultSampleComments).toMutableList()
        list.add(0, comment)
        currentMap[mediaId] = list
        _comments.value = currentMap
    }

    fun markNotificationAsRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isUnread = false) else it
        }
    }

    fun getPlans(): List<SubscriptionPlan> {
        return listOf(
            SubscriptionPlan(
                id = "plan_free",
                titleAr = "الباقة المجانية",
                titleEn = "Free Plan",
                priceAr = "0 د.ج / مجاناً",
                priceEn = "Free",
                periodAr = "مدى الحياة",
                periodEn = "Forever",
                featuresAr = listOf(
                    "مشاهدة بجودة 720p HD القياسية",
                    "تحتوي على فواصل إعلانية قصيرة",
                    "بث على جهاز واحد فقط",
                    "محتوى الأفلام والمسلسلات الأساسي"
                ),
                featuresEn = listOf(
                    "Standard 720p HD streaming",
                    "Supported with short ad breaks",
                    "Single device playback",
                    "Standard drama & movie library"
                ),
                isRecommended = false,
                badgeAr = "الأساسية",
                badgeEn = "Standard"
            ),
            SubscriptionPlan(
                id = "plan_monthly_vip",
                titleAr = "VIP شهري مميز",
                titleEn = "VIP Monthly",
                priceAr = "450 د.ج / شهرياً ($3.99)",
                priceEn = "$3.99 / month",
                periodAr = "تجديد شهري",
                periodEn = "Billed monthly",
                featuresAr = listOf(
                    "بدون أي إعلانات نهائياً (تجربة نقية)",
                    "جودة فائقة Full HD 1080p",
                    "تحميل غير محدود للمشاهدة بدون إنترنت",
                    "وصول مبكر لجميع الحلقات الجديدة قبل الجميع",
                    "تشغيل متزامن على 3 أجهزة"
                ),
                featuresEn = listOf(
                    "100% Ad-free streaming",
                    "Ultra crisp Full HD 1080p",
                    "Unlimited offline downloads",
                    "Early access to fresh drama episodes",
                    "Simultaneous play on 3 devices"
                ),
                isRecommended = true,
                badgeAr = "الأكثر شعبية 🔥",
                badgeEn = "Most Popular 🔥"
            ),
            SubscriptionPlan(
                id = "plan_annual_vip",
                titleAr = "VIP السنوي الذهبي",
                titleEn = "VIP Annual Gold",
                priceAr = "3,900 د.ج / سنوياً ($29.99)",
                priceEn = "$29.99 / year",
                periodAr = "وفر 40% سنوياً",
                periodEn = "Save 40% yearly",
                featuresAr = listOf(
                    "كل مميزات باقة VIP بدون إعلانات",
                    "أعلى جودة سينمائية 4K Ultra HD مع صوت Dolby",
                    "مشاهدة عائلية على 5 أجهزة في آن واحد",
                    "شارة المشترك الذهبي وشات دعم فني فوري VIP",
                    "تنزيل بجودة خارقة وخوادم بث فائقة السرعة"
                ),
                featuresEn = listOf(
                    "All VIP perks included completely ad-free",
                    "Cinematic 4K Ultra HD & Dolby Atmos",
                    "5 concurrent family screens",
                    "Gold member badge & Priority 24/7 VIP support",
                    "Blazing fast dedicated CDN servers"
                ),
                isRecommended = false,
                badgeAr = "القيمة الأفضل 💎",
                badgeEn = "Best Value 💎"
            )
        )
    }

    companion object {
        private fun createShortDramaEpisodes(
            prefix: String,
            seriesTitleAr: String,
            episodeTitlesAr: List<String>
        ): List<Episode> {
            val sampleStreams = listOf(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
            )
            val thumbnails = listOf(
                "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=500&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&auto=format&fit=crop&q=80"
            )
            return episodeTitlesAr.mapIndexed { index, titleAr ->
                val epNum = index + 1
                Episode(
                    id = "${prefix}_ep_${epNum}",
                    episodeNumber = epNum,
                    titleAr = "الحلقة $epNum: $titleAr",
                    titleEn = "Episode $epNum: Part $epNum",
                    duration = "02:45 د",
                    videoUrl = sampleStreams[index % sampleStreams.size],
                    thumbnail = thumbnails[index % thumbnails.size],
                    descriptionAr = "حلقة قصيرة مشوقة مليئة بالإثارة والدراما السريعة.",
                    descriptionEn = "A fast-paced dramatic episode with gripping cliffhangers.",
                    isVipOnly = epNum > 4,
                    requiresAdToUnlock = epNum > 1
                )
            }
        }

        private val billionaireTitles = listOf(
            "الإهانة في قاعة الاحتفال",
            "الكشف عن الهوية الحقيقية",
            "صفعة الملياردير الصامت",
            "إنقاذ سيدة الأعمال",
            "العقد الملياري السري",
            "فضح الخيانة الكبرى",
            "مواجهة برج التجارة",
            "استرداد الحق المسلوب",
            "اعتراف تحت المطر",
            "حفل الخطوبة المفاجئ",
            "سقوط رئيس المجموعة",
            "الفخ المحكم",
            "صدمة العائلة الأرستقراطية",
            "كشف الحقيقة الكاملة",
            "إنقاذ في اللحظة الأخيرة",
            "السيطرة على الشركة",
            "الندم والاعتذار",
            "استعادة الكرامة",
            "التتويج والنهاية السعيدة"
        )

        private val loveRegretTitles = listOf(
            "طرد العروس في يوم الزفاف",
            "اللقاء بعد ثلاث سنوات",
            "الهوية الخفية لطبيبة الجراحة",
            "إنقاذ طفل العائلة الثرية",
            "الندم الذي بدأ يشتعل",
            "حقيقة المرض المزعوم",
            "المناقصة الدولية الكبرى",
            "طلب المغفرة المستحيل",
            "ظهور المنافس الأقوى",
            "الهدية الغامضة",
            "فضح المؤامرة العائلية",
            "المواجهة في المستشفى",
            "حماية في الخفاء",
            "الانهيار والاعتراف الصادق",
            "اختطاف ومطاردة سريعة",
            "التضحية الكبرى",
            "الفرصة الثانية",
            "زفاف الأحلام الحقيقي",
            "النهاية الأسطورية السعيدة"
        )

        private val initialMedia = listOf(
            // SHORT DRAMAS (المسلسلات القصيرة - 19 حلقة متتالية سريعة الإيقاع مثل لقطة الشاشة)
            MediaItem(
                id = "media_short_drama_billionaire",
                titleAr = "وريث العائلة الخفي: انتقام الملياردير المتنكر",
                titleEn = "Silent Heir: The Secret Billionaire",
                originalTitle = "The Hidden Heir's Vengeance",
                type = MediaType.SHORT_DRAMA,
                descriptionAr = "مسلسل قصير درامي سريع (19 حلقة): بعد ثلاث سنوات من الإهانة والتنكر بصفة حارس أمن متواضع، يقرر وريث أكبر مجموعة استثمارية في آسيا خلع القناع والانتقام من كل من ظلمه واستعادة كرامة حبيبته.",
                descriptionEn = "A trending 19-episode short drama series: After 3 years undercover, the secret heir to a multi-billion empire reveals his true identity and takes down everyone who wronged him.",
                posterUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                durationText = "19 حلقة • مسلسل قصير",
                releaseYear = 2026,
                rating = 9.8,
                ageRating = "+13",
                genreAr = "مسلسلات قصيرة • دراما وانتقام",
                genreEn = "Short Drama • Revenge & Romance",
                cast = listOf("تشانغ وي", "لين يو", "وانغ شين"),
                director = "شين مينغ",
                isFeatured = true,
                isTrending = true,
                trendingRank = 1,
                matchPercentage = 99,
                viewCount = "3.8M",
                tags = listOf("مسلسلات قصيرة", "انتقام", "ملياردير", "دراما صينية", "رومانسية سريعة"),
                isVerticalFormat = true,
                episodes = createShortDramaEpisodes("billionaire", "وريث العائلة الخفي", billionaireTitles)
            ),
            MediaItem(
                id = "media_short_drama_love_regret",
                titleAr = "حب بعد فوات الأوان: ندم الرئيس التنفيذي",
                titleEn = "Love After Heartbreak: The CEO's Regret",
                originalTitle = "Too Late for Regret",
                type = MediaType.SHORT_DRAMA,
                descriptionAr = "مسلسل قصير رومانسي درامي (19 حلقة): بعد أن تخلى عنها ظناً أنها فتاة بلا مأوى، تعود بعد 3 سنوات كأشهر جراحة وسيدة أعمال ليركع أمامها نادماً طالباً المغفرة.",
                descriptionEn = "19-episode trending mini-drama: He left her penniless. 3 years later she returns as a renowned medical tycoon, and he will do anything to win her back.",
                posterUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                durationText = "19 حلقة • دراما عاطفية",
                releaseYear = 2026,
                rating = 9.6,
                ageRating = "+13",
                genreAr = "مسلسلات قصيرة • رومانسية وندم",
                genreEn = "Short Drama • Romance",
                cast = listOf("سو يان", "قوه ران", "هان لي"),
                director = "دونغ تشي",
                isFeatured = true,
                isTrending = true,
                trendingRank = 2,
                matchPercentage = 98,
                viewCount = "2.9M",
                tags = listOf("مسلسلات قصيرة", "رومانسية", "ندم", "سيدة أعمال", "دراما كورية وصينية"),
                isVerticalFormat = true,
                episodes = createShortDramaEpisodes("love_regret", "حب بعد فوات الأوان", loveRegretTitles)
            ),
            MediaItem(
                id = "media_tears_of_steel",
                titleAr = "دموع الفولاذ",
                titleEn = "Tears of Steel",
                originalTitle = "Tears of Steel",
                type = MediaType.SHORT_FILM,
                descriptionAr = "في مستقبل ديستوبي غامض تدور أحداثه في أمستردام، تحاول مجموعة من المقاتلين والعلماء إنقاذ كوكب الأرض من سيطرة الروبوتات والذكاء الاصطناعي عبر استرجاع ذكريات حب الماضي المؤلمة.",
                descriptionEn = "Set in a dystopian future in Amsterdam, a group of scientists and freedom fighters battle rogue AI mechs while attempting to resolve a poignant past romance.",
                posterUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                durationText = "12:14 دقيقة",
                releaseYear = 2024,
                rating = 9.4,
                ageRating = "+16",
                genreAr = "خيال علمي • إثارة",
                genreEn = "Sci-Fi • Thriller",
                cast = listOf("ديريك دي لينت", "فانيسا رادمان", "دينيس ريفرز"),
                director = "إيان هوبرت",
                isFeatured = true,
                isTrending = true,
                trendingRank = 1,
                matchPercentage = 99,
                viewCount = "2.4M",
                tags = listOf("خيال علمي", "روبوتات", "أكشن", "سينما قصيرة")
            ),
            MediaItem(
                id = "media_series_shadows",
                titleAr = "مسلسل: مطاردة الظلال",
                titleEn = "Shadow Pursuit Series",
                originalTitle = "Shadow Pursuit",
                type = MediaType.SERIES,
                descriptionAr = "مسلسل دراما وتشويق بوليسي قصير: يلاحق المحقق كريم خيوط شبكة غامضة تنفذ عمليات اختراق خطيرة في العاصمة، ليكتشف أن أقرب الناس إليه متورط حتى النخاع.",
                descriptionEn = "A thrilling high-stakes short crime drama series following investigator Karim as he unravels a cyber conspiracy inside the city.",
                posterUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                durationText = "3 حلقات • دراما متواصلة",
                releaseYear = 2025,
                rating = 9.2,
                ageRating = "+16",
                genreAr = "مسلسلات دراما • تشويق",
                genreEn = "Drama Series • Suspense",
                cast = listOf("سامي مروان", "نور الهدى", "حمزة قاسم"),
                director = "رضا سلامي",
                isFeatured = true,
                isTrending = true,
                trendingRank = 2,
                matchPercentage = 97,
                viewCount = "1.8M",
                tags = listOf("مسلسلات", "دراما", "غموض", "إثارة"),
                episodes = listOf(
                    Episode(
                        id = "ep_shadows_1",
                        episodeNumber = 1,
                        titleAr = "الحلقة 1: نقطة الصفر والإنذار",
                        titleEn = "Episode 1: Ground Zero",
                        duration = "15:00 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "تبدأ القصة بتلقي اتصال طارئ في منتصف الليل يكشف عن اختراق أمني ضخم داخل البنك المركزي.",
                        descriptionEn = "An urgent midnight call exposes a massive breach in the central vault."
                    ),
                    Episode(
                        id = "ep_shadows_2",
                        episodeNumber = 2,
                        titleAr = "الحلقة 2: في شباك العنكبوت",
                        titleEn = "Episode 2: Web of Secrets",
                        duration = "14:20 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "مطاردة شرسة في أزقة المدينة القديمة تكشف عن هوية العميل المزدوج الذي يراقب المحقق.",
                        descriptionEn = "A gripping chase reveals the hidden operative pulling the strings."
                    ),
                    Episode(
                        id = "ep_shadows_3",
                        episodeNumber = 3,
                        titleAr = "الحلقة 3: المواجهة الحاسمة والأخيرة",
                        titleEn = "Episode 3: The Final Standoff",
                        duration = "16:45 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "الحلقة الأخيرة والمثيرة: مواجهة وجهاً لوجه فوق برج المراقبة لحسم المعركة وفك اللغز النهائي.",
                        descriptionEn = "The dramatic finale showdown on top of the transmission tower."
                    )
                )
            ),
            MediaItem(
                id = "media_sintel",
                titleAr = "سينتل: رحلة التنين المفقود",
                titleEn = "Sintel: Dragon's Quest",
                originalTitle = "Sintel",
                type = MediaType.SHORT_FILM,
                descriptionAr = "قصة ملحمية مؤثرة لفتاة مقاتلة وحيدة تعبر الصحاري والجبال الثلجية وتواجه الوحوش الضارية في رحلة بحث يائسة عن تنين صغير قامت بتربيته وتم اختطافه.",
                descriptionEn = "A moving epic short animation about a solitary warrior girl journeying across harsh wastelands to rescue her kidnapped baby dragon.",
                posterUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                durationText = "15:22 دقيقة",
                releaseYear = 2024,
                rating = 9.1,
                ageRating = "+13",
                genreAr = "فانتازيا • دراما عاطفية",
                genreEn = "Fantasy • Emotional Drama",
                cast = listOf("هالينا رين", "توم هوفمان"),
                director = "كولين ليفي",
                isTrending = true,
                trendingRank = 3,
                matchPercentage = 95,
                viewCount = "3.1M",
                tags = listOf("أنيميشن", "فانتازيا", "دراما", "تنين")
            ),
            MediaItem(
                id = "media_big_buck_bunny",
                titleAr = "مغامرة الأرنب الحارس",
                titleEn = "Big Buck Bunny",
                originalTitle = "Big Buck Bunny",
                type = MediaType.SHORT_FILM,
                descriptionAr = "فيلم رسوم متحركة عائلي وكوميدي شهير يحكي قصة أرنب عملاق محب للسلام يقرر تلقين ثلاثة سناجب مشاكسة درساً لن ينسوه بعدما أزعجوا غابته الهادئة.",
                descriptionEn = "A comedy animation short featuring a gentle giant bunny who stands up against forest bullies to protect nature.",
                posterUrl = "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                durationText = "09:56 دقيقة",
                releaseYear = 2023,
                rating = 8.8,
                ageRating = "جميع الأعمار",
                genreAr = "كوميديا • عائلي",
                genreEn = "Comedy • Family",
                cast = listOf("شخصيات كرتونية محبوبة"),
                director = "ساشا غودليك",
                isTrending = true,
                trendingRank = 4,
                matchPercentage = 91,
                viewCount = "5.5M",
                tags = listOf("كوميديا", "عائلي", "أنيميشن", "مرح")
            ),
            MediaItem(
                id = "media_elephants_dream",
                titleAr = "حلم الفيلة: متاهة الآلات",
                titleEn = "Elephants Dream",
                originalTitle = "Elephants Dream",
                type = MediaType.SHORT_FILM,
                descriptionAr = "فيلم خيال علمي ودراما سريالية عميقة، يدور داخل آلة عملاقة معقدة حيث يحاول مرشد عجوز حماية رفيقه الشاب من الوقوع في فخاخ أوهام العقل.",
                descriptionEn = "A thought-provoking sci-fi and mystery short film about two travelers exploring the mysterious depths of an endless mechanical universe.",
                posterUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                durationText = "10:54 دقيقة",
                releaseYear = 2023,
                rating = 8.7,
                ageRating = "+13",
                genreAr = "خيال علمي • غموض",
                genreEn = "Sci-Fi • Mystery",
                cast = listOf("تيكو كوجيك", "كاسبار فون سيك"),
                director = "باسام كورداهل",
                isTrending = false,
                matchPercentage = 88,
                viewCount = "920K",
                tags = listOf("غموض", "خيال علمي", "فلسفة")
            ),
            MediaItem(
                id = "media_series_escape",
                titleAr = "مسلسل: الهروب الكبير",
                titleEn = "The Great Escape Drama",
                originalTitle = "The Great Escape",
                type = MediaType.SERIES,
                descriptionAr = "سلسلة درامية حابسة للأنفاس: خطة هروب جريئة عبر المرتفعات الجبلية المحاصرة، حيث تتسارع الأحداث وسط صراع نفسي وعاطفي حاد بين النجاة والواجب.",
                descriptionEn = "A nail-biting survival drama series through mountain passes with unexpected plot twists and emotional decisions.",
                posterUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                durationText = "حلقات حصرية • VIP",
                releaseYear = 2025,
                rating = 9.5,
                ageRating = "+18",
                genreAr = "مسلسلات دراما • حركة",
                genreEn = "Action Drama • Series",
                cast = listOf("يوسف الخال", "نادين تحسين", "خالد الصاوي"),
                director = "طارق العريان",
                isVipOnly = true,
                isFeatured = true,
                isTrending = true,
                trendingRank = 5,
                matchPercentage = 99,
                viewCount = "4.2M",
                tags = listOf("VIP", "دراما", "أكشن", "إثارة"),
                episodes = listOf(
                    Episode(
                        id = "ep_esc_1",
                        episodeNumber = 1,
                        titleAr = "الحلقة 1: ساعة الصفر تحت الجليد",
                        titleEn = "Episode 1: Zero Hour Ice",
                        duration = "18:10 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "انطلاق خطة الإخلاء السرية وسط عاصفة ثلجية عاتية تفاجئ الجميع.",
                        descriptionEn = "Evacuation begins in the midst of a violent snow blizzard."
                    ),
                    Episode(
                        id = "ep_esc_2",
                        episodeNumber = 2,
                        titleAr = "الحلقة 2: حافة الهاوية والصمود",
                        titleEn = "Episode 2: The Cliff Edge",
                        duration = "17:30 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "محاصرة الفريق في وادٍ سحيق، والاعتماد على خطة بديلة خطيرة.",
                        descriptionEn = "Surrounded in a deep canyon, they deploy a dangerous backup plan."
                    ),
                    Episode(
                        id = "ep_esc_3",
                        episodeNumber = 3,
                        titleAr = "الحلقة 3: ضوء في نهاية النفق",
                        titleEn = "Episode 3: Light at Tunnel's End",
                        duration = "19:15 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "المرحلة الحاسمة لاختراق الحصار الجبلي والوصول إلى بر الأمان.",
                        descriptionEn = "The critical stage of breaking through the perimeter."
                    ),
                    Episode(
                        id = "ep_esc_4",
                        episodeNumber = 4,
                        titleAr = "الحلقة 4: الخلاص والبداية الجديدة",
                        titleEn = "Episode 4: Redemption & Rebirth",
                        duration = "21:00 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "الخاتمة المؤثرة التي تكشف التضحية الكبرى ونجاح مهمة الإنقاذ.",
                        descriptionEn = "The dramatic series finale revealing the great sacrifice."
                    )
                )
            ),
            MediaItem(
                id = "media_series_capital_code",
                titleAr = "مسلسل: شفرة العاصمة",
                titleEn = "Capital Code Series",
                originalTitle = "Capital Code",
                type = MediaType.SERIES,
                descriptionAr = "مسلسل دراما وتشويق تقني معاصر: مهندسة برمجيات عبقرية تكتشف ثغرة خفية تتحكم في شبكة الطاقة والاتصالات في العاصمة، وتخوض سباقاً مع الوقت ضد منظمة دولية مجهولة.",
                descriptionEn = "A high-octane cyber-thriller series where a brilliant software architect uncovers a backdoor controlling the metropolitan infrastructure.",
                posterUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                durationText = "3 حلقات • تشويق ودراما",
                releaseYear = 2025,
                rating = 9.3,
                ageRating = "+16",
                genreAr = "مسلسلات دراما • تقنية وغموض",
                genreEn = "Drama Series • Cyber Thriller",
                cast = listOf("ريم بوشناق", "زياد برجي", "أمين الناجي"),
                director = "هشام العسري",
                isFeatured = false,
                isTrending = true,
                trendingRank = 6,
                matchPercentage = 96,
                viewCount = "1.5M",
                tags = listOf("مسلسلات", "دراما", "تقنية", "غموض"),
                episodes = listOf(
                    Episode(
                        id = "ep_cap_1",
                        episodeNumber = 1,
                        titleAr = "الحلقة 1: الشفرة الميتة",
                        titleEn = "Episode 1: Dead Code",
                        duration = "16:20 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "اكتشاف إشارة مشفرة تنبثق من خوادم الوزارة المركزية دون مصدر محدد.",
                        descriptionEn = "A mysterious encoded signal appears from internal servers."
                    ),
                    Episode(
                        id = "ep_cap_2",
                        episodeNumber = 2,
                        titleAr = "الحلقة 2: انقطاع التيار",
                        titleEn = "Episode 2: Blackout",
                        duration = "18:40 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "انقطاع مفاجئ للكهرباء في المدينة واختفاء ملفات الأمان الحيوية.",
                        descriptionEn = "A citywide blackout cripples communication networks."
                    ),
                    Episode(
                        id = "ep_cap_3",
                        episodeNumber = 3,
                        titleAr = "الحلقة 3: جدار الحماية الأخير",
                        titleEn = "Episode 3: The Last Firewall",
                        duration = "22:10 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "المعركة الرقمية الأخيرة لإعادة السيطرة وكشف الشخص المتخفي.",
                        descriptionEn = "The ultimate digital confrontation to regain control."
                    )
                )
            ),
            MediaItem(
                id = "media_series_desert_secrets",
                titleAr = "مسلسل: أسرار الصحراء الكبرى",
                titleEn = "Desert Secrets",
                originalTitle = "Desert Secrets",
                type = MediaType.SERIES,
                descriptionAr = "ملحمة درامية مشوقة تم تصويرها في صحراء الطاسيلي والهقار: بعثة استكشافية تبحث عن مدينة أثرية مفقودة محفورة في قلب الجبال الصخرية وتواجه تحديات بيئية وصراعاً بين أعضاء الفريق.",
                descriptionEn = "An epic desert adventure and drama series filmed in breathtaking dunes following an archaeological expedition seeking an ancient lost city.",
                posterUrl = "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1473580044384-7ba9967e16a0?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
                durationText = "3 حلقات • تراث ومغامرة",
                releaseYear = 2025,
                rating = 9.6,
                ageRating = "+13",
                genreAr = "مسلسلات دراما • مغامرة وتراث",
                genreEn = "Drama Series • Desert Adventure",
                cast = listOf("حسان كشاش", "شافية بوذراع", "نبيل عسلي"),
                director = "مرزاق علواش",
                isFeatured = true,
                isTrending = true,
                trendingRank = 7,
                matchPercentage = 98,
                viewCount = "2.8M",
                tags = listOf("صحراء", "تراث", "مغامرة", "مسلسلات"),
                episodes = listOf(
                    Episode(
                        id = "ep_des_1",
                        episodeNumber = 1,
                        titleAr = "الحلقة 1: خارطة الرمال الذهبية",
                        titleEn = "Episode 1: Map of Gold",
                        duration = "19:00 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "العثور على مخطوطة طارقية قديمة ترشد إلى موقع بئر أثري غامض.",
                        descriptionEn = "Discovery of an ancient manuscript pointing to a lost well."
                    ),
                    Episode(
                        id = "ep_des_2",
                        episodeNumber = 2,
                        titleAr = "الحلقة 2: رمال الغضب",
                        titleEn = "Episode 2: Sands of Fury",
                        duration = "18:20 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1473580044384-7ba9967e16a0?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "عاصفة رملية تقطع خطوط الإمداد وتجبر البعثة على الاحتماء بالكهوف.",
                        descriptionEn = "A violent sandstorm tests the survival skills of the team."
                    ),
                    Episode(
                        id = "ep_des_3",
                        episodeNumber = 3,
                        titleAr = "الحلقة 3: كنوز الذاكرة",
                        titleEn = "Episode 3: Treasures of Time",
                        duration = "24:00 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "الوصول إلى الوادي السري واكتشاف النقوش الصخرية التي تحكي قصة الأجداد.",
                        descriptionEn = "Arrival at the hidden valley and the emotional historic revelation."
                    )
                )
            ),
            MediaItem(
                id = "media_series_sunset_station",
                titleAr = "مسلسل: محطة الغروب",
                titleEn = "Sunset Station",
                originalTitle = "Sunset Station",
                type = MediaType.SERIES,
                descriptionAr = "دراما اجتماعية وعاطفية مؤثرة: تلتقي مصائر مسافرين غرباء في محطة قطار ريفية قديمة أثناء تأخر الرحلة الأخيرة، حيث يبوح كل منهم بقصته وجروحه الدفينة.",
                descriptionEn = "A poignant social and character-driven drama series where the paths of strangers cross at a secluded train depot at sundown.",
                posterUrl = "https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1474487548417-781cb71495f3?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
                durationText = "3 حلقات • دراما إنسانية",
                releaseYear = 2024,
                rating = 9.0,
                ageRating = "+13",
                genreAr = "مسلسلات دراما • اجتماعي وعاطفي",
                genreEn = "Drama Series • Social Drama",
                cast = listOf("منى واصف", "جمال سليمان", "سلاف فواخرجي"),
                director = "حاتم علي",
                isFeatured = false,
                isTrending = false,
                matchPercentage = 94,
                viewCount = "1.1M",
                tags = listOf("دراما", "اجتماعي", "رومانسي", "مسلسلات"),
                episodes = listOf(
                    Episode(
                        id = "ep_sun_1",
                        episodeNumber = 1,
                        titleAr = "الحلقة 1: تذكرة ذهاب فقط",
                        titleEn = "Episode 1: One-Way Ticket",
                        duration = "17:15 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1517649763962-0c623266ddc0?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "وصول الركاب إلى المحطة وسماع إعلان تأجيل القطار حتى بزوغ الفجر.",
                        descriptionEn = "Passengers arrive as the final train gets delayed."
                    ),
                    Episode(
                        id = "ep_sun_2",
                        episodeNumber = 2,
                        titleAr = "الحلقة 2: اعترافات منتصف الليل",
                        titleEn = "Episode 2: Midnight Confessions",
                        duration = "19:50 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1474487548417-781cb71495f3?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "حوارات عميقة ومؤثرة بين أجيال مختلفة تكشف دروس الحياة.",
                        descriptionEn = "Heartfelt talks reveal buried secrets and redemption."
                    ),
                    Episode(
                        id = "ep_sun_3",
                        episodeNumber = 3,
                        titleAr = "الحلقة 3: صفير القطار القادم",
                        titleEn = "Episode 3: The Next Journey",
                        duration = "18:00 د",
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                        thumbnail = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=500&auto=format&fit=crop&q=80",
                        descriptionAr = "مع إشراقة الصباح يصل القطار وتتغير نظرة كل مسافر لحياته.",
                        descriptionEn = "Morning arrives bringing new beginnings."
                    )
                )
            ),
            MediaItem(
                id = "media_blaze_of_valor",
                titleAr = "فيلم: لهيب المعركة والشجاعة",
                titleEn = "Blaze of Valor",
                originalTitle = "Blaze of Valor",
                type = MediaType.MOVIE,
                descriptionAr = "فيلم سينمائي ملحمي حائز على جوائز تصوير: فرقة من رجال الإطفاء والإنقاذ تخوض معركة مستميتة لاحتواء حريق هائل يهدد بلدة جبلية محاصرة.",
                descriptionEn = "A gripping cinematic action drama following a squad of mountain rescue firefighters fighting to protect a trapped historic township.",
                posterUrl = "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                durationText = "15:45 دقيقة",
                releaseYear = 2025,
                rating = 9.3,
                ageRating = "+16",
                genreAr = "أكشن وتشويق • بطولات وإنقاذ",
                genreEn = "Action & Thriller • Heroism",
                cast = listOf("ياسين بن قمرة", "خالد النبوي", "هشام بهلول"),
                director = "أحمد نادر جلال",
                isFeatured = true,
                isTrending = true,
                trendingRank = 8,
                matchPercentage = 97,
                viewCount = "2.1M",
                tags = listOf("أكشن", "إنقاذ", "تشويق", "بطولة")
            ),
            MediaItem(
                id = "media_minute_silence",
                titleAr = "فيلم: دقيقة صمت",
                titleEn = "Minute of Silence",
                originalTitle = "Minute of Silence",
                type = MediaType.SHORT_FILM,
                descriptionAr = "فيلم دراما قصير مكثف ومؤثر: في قاعة انتظار المستشفى، تعيش عائلة واحدة دقيقة صمت طويلة تنتظر فيها خروج الطبيب بقرار يغير مجرى حياتهم بالكامل.",
                descriptionEn = "An emotionally charged drama short centered on the tension, hope, and resilience of a family in a pivotal turning point.",
                posterUrl = "https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1538688525198-9b88f6f53126?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                durationText = "11:20 دقيقة",
                releaseYear = 2024,
                rating = 8.9,
                ageRating = "جميع الأعمار",
                genreAr = "أفلام قصيرة • دراما إنسانية",
                genreEn = "Short Films • Human Drama",
                cast = listOf("فاطمة بلحاج", "سيد علي كويرات"),
                director = "ليليا والي",
                isFeatured = false,
                isTrending = false,
                matchPercentage = 92,
                viewCount = "850K",
                tags = listOf("أفلام قصيرة", "دراما", "عاطفي")
            ),
            MediaItem(
                id = "media_speed_rush",
                titleAr = "فيلم: سباق ضد الزمن",
                titleEn = "Time Rush: High Velocity",
                originalTitle = "Time Rush",
                type = MediaType.MOVIE,
                descriptionAr = "مطاردات سيارات وحركات بهلوانية سريعة ومثيرة في شوارع المدينة الساحلية لنقل ترياق حيوي قبل انقضاء الموعد المحدد.",
                descriptionEn = "An adrenaline-pumping high velocity action film featuring breathtaking vehicle stunts through coastal mountain curves.",
                posterUrl = "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
                durationText = "14:10 دقيقة",
                releaseYear = 2025,
                rating = 9.1,
                ageRating = "+16",
                genreAr = "أكشن وتشويق • سرعة ومطاردات",
                genreEn = "Action • High Speed Chase",
                cast = listOf("أحمد السقا", "باسم سمرة", "أمير كرارة"),
                director = "مروان حامد",
                isFeatured = false,
                isTrending = true,
                trendingRank = 9,
                matchPercentage = 96,
                viewCount = "3.4M",
                tags = listOf("أكشن", "سيارات", "سرعة", "تشويق")
            ),
            MediaItem(
                id = "media_lost_oasis",
                titleAr = "فيلم: الواحة المنسية",
                titleEn = "The Lost Oasis",
                originalTitle = "The Lost Oasis",
                type = MediaType.SHORT_FILM,
                descriptionAr = "فيلم وثائقي وسينمائي ساحر يستكشف جنة طبيعية مخبأة بين الكثبان الرملية وحياة الكائنات النادرة وعادات أهل البادية الأصيلة.",
                descriptionEn = "A visually stunning documentary short capturing pristine natural landscapes and the timeless traditions of desert inhabitants.",
                posterUrl = "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1473580044384-7ba9967e16a0?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                durationText = "16:40 دقيقة",
                releaseYear = 2024,
                rating = 9.5,
                ageRating = "جميع الأعمار",
                genreAr = "وثائقي وتراث • استكشاف الطبيعة",
                genreEn = "Documentary • Nature Discovery",
                cast = listOf("رواية صوتية: الدكتور عبد القادر بن عيسى"),
                director = "جمال بن ديدوش",
                isFeatured = false,
                isTrending = false,
                matchPercentage = 95,
                viewCount = "1.7M",
                tags = listOf("وثائقي", "طبيعة", "تراث", "هدوء")
            ),
            MediaItem(
                id = "media_old_casbah",
                titleAr = "فيلم: أسرار القصبة العتيقة",
                titleEn = "Secrets of the Casbah",
                originalTitle = "Secrets of the Casbah",
                type = MediaType.SHORT_FILM,
                descriptionAr = "رحلة تصويرية آسرة في دروب وأزقة القصبة البيضاء العريقة، حيث يلتقي صانع نحاس مسن بشاب رسام لتبادل أسرار العمارة والفن الأندلسي.",
                descriptionEn = "An evocative cultural short film capturing the architectural poetry and living memory inside the historic whitewashed Casbah.",
                posterUrl = "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1548013146-72479768bada?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                durationText = "13:30 دقيقة",
                releaseYear = 2024,
                rating = 9.2,
                ageRating = "جميع الأعمار",
                genreAr = "وثائقي وتراث • سينما فنية",
                genreEn = "Culture • Heritage & Art",
                cast = listOf("بشير سلامي", "آمال حيمر"),
                director = "يمينة بشير شويخ",
                isFeatured = false,
                isTrending = false,
                matchPercentage = 93,
                viewCount = "990K",
                tags = listOf("تراث", "فن", "قصبة", "ثقافة")
            ),
            MediaItem(
                id = "media_stellar_voyage",
                titleAr = "فيلم: ما وراء مدار المشتري",
                titleEn = "Beyond Jupiter's Orbit",
                originalTitle = "Beyond Jupiter's Orbit",
                type = MediaType.MOVIE,
                descriptionAr = "خيال علمي فضائي ملحمي: مستكشف فضاء وحيد في رحلة أبحاث طويلة يتلقى بثاً غامضاً من أحد أقمار المشتري الجليدية يغير فهم البشرية للكون.",
                descriptionEn = "An epic space exploration sci-fi short where a deep-space cartographer detects a resonant signal beneath an icy moon.",
                posterUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                durationText = "15:00 دقيقة",
                releaseYear = 2025,
                rating = 9.4,
                ageRating = "+13",
                genreAr = "خيال علمي • فضاء واستكشاف",
                genreEn = "Sci-Fi • Space Exploration",
                cast = listOf("كريم الغربي", "سلمى محجوبي"),
                director = "نوري بوزيد",
                isFeatured = true,
                isTrending = true,
                trendingRank = 10,
                matchPercentage = 99,
                viewCount = "1.9M",
                tags = listOf("خيال علمي", "فضاء", "غموض", "أفلام")
            ),
            MediaItem(
                id = "media_hearty_comedy",
                titleAr = "فيلم: يوم غير عادي في الحومة",
                titleEn = "Unusual Day in the Alley",
                originalTitle = "Unusual Day",
                type = MediaType.SHORT_FILM,
                descriptionAr = "كوميديا اجتماعية ساخرة ومبهجة: سلسلة من المفارقات المضحكة تنشأ عندما يقرر جار طيب تنظيم حفل زفاف مفاجئ لصديقه وسط مواقف طريفة مع الجيران.",
                descriptionEn = "A delightful neighborhood comedy short full of humor, warm human connections, and witty banter in a bustling quarter.",
                posterUrl = "https://images.unsplash.com/photo-1514306191717-452ec28c7814?w=800&auto=format&fit=crop&q=80",
                backdropUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80",
                videoStreamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                durationText = "12:50 دقيقة",
                releaseYear = 2024,
                rating = 8.7,
                ageRating = "جميع الأعمار",
                genreAr = "كوميديا • عائلي واجتماعي",
                genreEn = "Comedy • Family & Social",
                cast = listOf("حسان بن زيراري", "بيونة", "صالح أوقروت"),
                director = "جعفر قاسم",
                isFeatured = false,
                isTrending = false,
                matchPercentage = 90,
                viewCount = "4.1M",
                tags = listOf("كوميديا", "ضحك", "عائلي", "حومة")
            )
        )

        private val defaultSampleComments = listOf(
            CommentItem(
                id = "c_1",
                authorName = "محمد الجزائري",
                avatarUrl = "",
                text = "تطبيق فارجة تحفة سينمائية حقيقية! جودة البث سريعة جداً بدون أي تقطيع والترجمة واضحة.",
                rating = 5.0f,
                timestamp = "منذ ساعتين",
                isVip = true,
                likes = 34
            ),
            CommentItem(
                id = "c_2",
                authorName = "سارة أحمد",
                avatarUrl = "",
                text = "القصة ممتعة ومؤثرة جداً.. إخراج رائع وموسيقى تصويرية تأخذك لعالم آخر!",
                rating = 4.5f,
                timestamp = "منذ 5 ساعات",
                isVip = false,
                likes = 18
            ),
            CommentItem(
                id = "c_3",
                authorName = "كريم بن ناصر",
                avatarUrl = "",
                text = "ميزة حفظ المحتوى للمشاهدة بدون إنترنت مفيدة للغاية في السفر، شكراً للقائمين على المنصة 👏",
                rating = 5.0f,
                timestamp = "أمس",
                isVip = true,
                likes = 42
            )
        )

        private val initialComments = mapOf(
            "media_tears_of_steel" to defaultSampleComments,
            "media_series_shadows" to listOf(
                CommentItem(
                    id = "c_sh_1",
                    authorName = "طارق الحكيم",
                    avatarUrl = "",
                    text = "الحلقة الثانية حبست أنفاسي! تسلسل الأحداث غير متوقع، ننتظر الموسم القادم بفارغ الصبر!",
                    rating = 5.0f,
                    timestamp = "منذ يومين",
                    isVip = true,
                    likes = 59
                ),
                CommentItem(
                    id = "c_sh_2",
                    authorName = "ليلى عثمان",
                    avatarUrl = "",
                    text = "أفضل مسلسل دراما قصير شاهدته هذا العام، التمثيل احترافي والتصوير على مستوى عالمي.",
                    rating = 5.0f,
                    timestamp = "منذ 3 أيام",
                    isVip = false,
                    likes = 27
                )
            )
        )

        private val initialNotifications = listOf(
            NotificationModel(
                id = "notif_1",
                titleAr = "🔥 إصدار حصري جديد: مسلسل الهروب الكبير",
                titleEn = "🔥 New Release: The Great Escape Drama",
                bodyAr = "تمت إضافة حلقات جديدة كاملة بتقنية 4K Ultra HD لمشتركي منصة دراما وموفيز الآن!",
                bodyEn = "Brand new 4K episodes dropped on Fardja Drama & Movies platform!",
                timeAgoAr = "منذ 15 دقيقة",
                timeAgoEn = "15m ago",
                isUnread = true,
                type = "RELEASE",
                targetMediaId = "media_series_escape"
            ),
            NotificationModel(
                id = "notif_2",
                titleAr = "🎬 فيلم الأسبوع الموصى به: دموع الفولاذ",
                titleEn = "🎬 Movie of the Week: Tears of Steel",
                bodyAr = "حاصل على تقييم 9.4/10 متوفر الآن للمشاهدة المباشرة والتحميل أوفلاين.",
                bodyEn = "Rated 9.4/10, available for instant streaming and offline download.",
                timeAgoAr = "منذ ساعتين",
                timeAgoEn = "2h ago",
                isUnread = true,
                type = "RELEASE",
                targetMediaId = "media_tears_of_steel"
            ),
            NotificationModel(
                id = "notif_3",
                titleAr = "💎 عرض الترقية الذهبي VIP",
                titleEn = "💎 Golden VIP Subscription Special",
                bodyAr = "احصل على خصم 40% وتخلص من كل الإعلانات مع تنزيل بلا حدود للأجهزة العائلية.",
                bodyEn = "Save 40% with zero ads and unlimited downloads for all your screens.",
                timeAgoAr = "منذ يوم واحد",
                timeAgoEn = "1d ago",
                isUnread = false,
                type = "PROMO",
                targetMediaId = null
            )
        )
    }
}
