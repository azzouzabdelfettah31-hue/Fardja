package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SubscriptionPlan
import com.example.ui.MainViewModel
import com.example.ui.components.CinemaGold
import com.example.ui.components.CinemaRed
import com.example.ui.components.DarkCardBg
import com.example.ui.components.DarkSurface
import com.example.ui.components.TextMuted

@Composable
fun SubscriptionModal(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val plans = viewModel.allPlans
    val user by viewModel.userAccount.collectAsState()
    val isArabic = user.selectedLanguage == "ar"
    var selectedPlanId by remember { mutableStateOf("plan_monthly_vip") }
    var couponText by remember { mutableStateOf("") }
    var couponMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE0A090E))
            .clickable(enabled = false) {}
            .testTag("subscription_modal_root"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxSize(0.92f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = BorderStroke(1.dp, Color(0x44FFB800))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "اشتراكات دراما وموفيز VIP" else "Fardja VIP Subscriptions",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_subscription_modal_btn")
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isArabic) "اختر خطة الاشتراك المناسبة واستمتع بتجربة سينمائية فريدة دون إعلانات وبأعلى دقة 4K." else "Select your plan and enjoy ad-free 4K cinema experience.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Plans List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(plans) { plan ->
                        val isSelected = selectedPlanId == plan.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPlanId = plan.id }
                                .testTag("plan_card_${plan.id}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) Color(0xFF221A30) else DarkCardBg
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) CinemaGold else Color(0x22FFFFFF)
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = if (isArabic) plan.titleAr else plan.titleEn,
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isArabic) plan.priceAr else plan.priceEn,
                                            color = CinemaGold,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    if (plan.badgeAr.isNotBlank()) {
                                        Surface(
                                            color = if (plan.isRecommended) CinemaGold else CinemaRed,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = if (isArabic) plan.badgeAr else plan.badgeEn,
                                                color = if (plan.isRecommended) Color.Black else Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                val features = if (isArabic) plan.featuresAr else plan.featuresEn
                                features.forEach { feat ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = if (isSelected) CinemaGold else Color(0xFF46D369),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = feat,
                                            color = Color(0xFFDCD6E8),
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Coupon Activation Section
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = if (isArabic) "هل تملك كود هدية أو قسيمة خصم؟ (كود تجريبي: FARDJA2026)" else "Have a gift code? (Try: FARDJA2026)",
                                    color = CinemaGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = couponText,
                                        onValueChange = { couponText = it },
                                        placeholder = { Text("FARDJA2026", color = TextMuted, fontSize = 11.sp) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("coupon_input_field"),
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedBorderColor = CinemaGold,
                                            unfocusedBorderColor = Color(0x33FFFFFF)
                                        )
                                    )

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Button(
                                        onClick = {
                                            val ok = viewModel.activateCoupon(couponText)
                                            couponMessage = if (ok) {
                                                if (isArabic) "تم تفعيل الاشتراك الذهبي مجاناً!" else "VIP Activated successfully!"
                                            } else {
                                                if (isArabic) "الكود غير صحيح، جرب FARDJA2026" else "Invalid code. Try FARDJA2026"
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CinemaGold),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .height(44.dp)
                                            .testTag("apply_coupon_btn")
                                    ) {
                                        Text(
                                            text = if (isArabic) "تفعيل" else "Apply",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                couponMessage?.let { msg ->
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg,
                                        color = if (user.isVip) Color(0xFF46D369) else Color(0xFFEF5350),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Subscribe Action Button
                Button(
                    onClick = {
                        viewModel.toggleVipStatus()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (user.isVip) Color(0xFF46D369) else CinemaRed
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("confirm_subscription_btn")
                ) {
                    Icon(
                        Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (user.isVip) {
                            if (isArabic) "أنت مشترك بالفعل (إلغاء أو تعديل)" else "Active VIP Member (Modify)"
                        } else {
                            if (isArabic) "تأكيد الاشتراك وتفعيل باقة VIP" else "Subscribe & Activate VIP Now"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
