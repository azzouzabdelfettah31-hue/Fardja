package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.ui.MainViewModel
import com.example.ui.ads.AdMobBanner
import com.example.ui.components.AdBannerWidget
import com.example.ui.components.CinemaGold
import com.example.ui.components.CinemaRed
import com.example.ui.components.HeroBanner
import com.example.ui.components.MediaPosterCard
import com.example.ui.components.TextMuted
import com.example.ui.components.TrendingRankingCard

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onMediaClick: (MediaItem) -> Unit,
    onUpgradeClick: () -> Unit
) {
    val allMedia by viewModel.allMedia.collectAsState()
    val watchlist by viewModel.watchlistIds.collectAsState()
    val user by viewModel.userAccount.collectAsState()
    val isArabic = user.selectedLanguage == "ar"
    val selectedCategory by viewModel.selectedCategory.collectAsState()

    val categories = if (isArabic) {
        listOf("الكل", "مسلسلات قصيرة", "مسلسلات دراما", "أفلام قصيرة", "خيال علمي", "أكشن", "كوميديا", "وثائقي وتراث")
    } else {
        listOf("All", "Short Dramas", "Drama Series", "Short Films", "Sci-Fi", "Action", "Comedy", "Documentary")
    }

    val isCategoryFiltered = selectedCategory != "الكل" && selectedCategory != "All"
    val filteredMedia = if (isCategoryFiltered) {
        allMedia.filter { item ->
            when (selectedCategory) {
                "مسلسلات قصيرة", "Short Dramas" -> item.type == MediaType.SHORT_DRAMA || item.isVerticalFormat || item.tags.contains("مسلسلات قصيرة")
                "مسلسلات دراما", "Drama Series" -> item.type == MediaType.SERIES || item.genreAr.contains("دراما") || item.genreAr.contains("مسلسل")
                "أفلام قصيرة", "Short Films" -> item.type == MediaType.SHORT_FILM
                "خيال علمي", "Sci-Fi" -> item.genreAr.contains("خيال علمي") || item.genreEn.contains("Sci-Fi") || item.tags.contains("خيال علمي")
                "أكشن", "Action" -> item.genreAr.contains("أكشن") || item.genreEn.contains("Action") || item.tags.contains("أكشن")
                "كوميديا", "Comedy" -> item.genreAr.contains("كوميديا") || item.genreEn.contains("Comedy") || item.tags.contains("كوميديا")
                "وثائقي وتراث", "Documentary" -> item.genreAr.contains("وثائقي") || item.genreAr.contains("تراث") || item.tags.contains("وثائقي")
                else -> item.genreAr.contains(selectedCategory)
            }
        }
    } else emptyList()

    val heroMedia = allMedia.find { it.isFeatured } ?: allMedia.firstOrNull()
    val trendingMedia = allMedia.filter { it.isTrending }.sortedBy { it.trendingRank }
    val shortDramas = allMedia.filter { it.type == MediaType.SHORT_DRAMA || it.isVerticalFormat }
    val recommendedMedia = viewModel.getRecommendedMedia()
    val seriesList = allMedia.filter { it.type == MediaType.SERIES }
    val shortFilms = allMedia.filter { it.type == MediaType.SHORT_FILM }
    val sciFiFilms = allMedia.filter { it.genreAr.contains("خيال علمي") || it.tags.contains("خيال علمي") }
    val actionFilms = allMedia.filter { it.genreAr.contains("أكشن") || it.tags.contains("أكشن") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Category Filter Chips
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = (selectedCategory == cat) || (selectedCategory == "الكل" && cat == "All")
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setCategory(cat) },
                        label = {
                            Text(
                                text = cat,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CinemaRed,
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFF1E1A29),
                            labelColor = Color(0xFFDCD8E6)
                        ),
                        border = null,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("filter_chip_$cat")
                    )
                }
            }
        }

        if (isCategoryFiltered) {
            // Dedicated Category View
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(
                        text = "${if (isArabic) "تصنيف: " else "Category: "}$selectedCategory",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${filteredMedia.size} ${if (isArabic) "أعمال فنية ومسلسلات متوفرة للبث الفوري بجودة فائقة" else "titles ready to stream in high quality"}",
                        color = CinemaGold,
                        fontSize = 12.sp
                    )
                }
            }

            val chunkedItems = filteredMedia.chunked(2)
            items(chunkedItems) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEach { item ->
                        Box(modifier = Modifier.weight(1f)) {
                            MediaPosterCard(
                                media = item,
                                isArabic = isArabic,
                                isInWatchlist = watchlist.contains(item.id),
                                onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                                onClick = { onMediaClick(item) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    if (pair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        } else {
            // Full Cinema Home Layout
            // Hero Spotlight Banner
            if (heroMedia != null) {
                item {
                    HeroBanner(
                        media = heroMedia,
                        isInWatchlist = watchlist.contains(heroMedia.id),
                        isArabic = isArabic,
                        onWatchClick = { onMediaClick(heroMedia) },
                        onWatchlistClick = { viewModel.toggleWatchlist(heroMedia.id) },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // Ad Banner (Free users only)
            if (!user.isVip) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    AdBannerWidget(
                        isArabic = isArabic,
                        onUpgradeClick = onUpgradeClick,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // Section: Trending Top 10 Today
            item {
                SectionHeader(
                    title = if (isArabic) "الأكثر مشاهدة ورواجاً اليوم 🔥" else "Trending Today 🔥",
                    icon = {
                        Icon(
                            Icons.Default.LocalFireDepartment,
                            contentDescription = null,
                            tint = CinemaRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(trendingMedia) { item ->
                        TrendingRankingCard(
                            rank = item.trendingRank,
                            media = item,
                            isArabic = isArabic,
                            isInWatchlist = watchlist.contains(item.id),
                            onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                            onClick = { onMediaClick(item) }
                        )
                    }
                }
            }

            // Section: Trending Short Dramas (19 Episodes Mini-Series)
            if (shortDramas.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = if (isArabic) "المسلسلات القصيرة الرائجة (19 حلقة) ⚡" else "Trending Mini-Series (19 Episodes) ⚡",
                        icon = {
                            Icon(
                                Icons.Default.Tv,
                                contentDescription = null,
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(shortDramas) { item ->
                            MediaPosterCard(
                                media = item,
                                isArabic = isArabic,
                                isInWatchlist = watchlist.contains(item.id),
                                onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                                onClick = { onMediaClick(item) }
                            )
                        }
                    }
                }
            }

            // Real Google AdMob Banner for Non-VIP Users
            if (!user.isVip) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        AdMobBanner()
                    }
                }
            }

            // Section: Smart Recommendations
            item {
                SectionHeader(
                    title = if (isArabic) "موصى به لك بناءً على اهتماماتك 🎯" else "Recommended For You 🎯",
                    icon = {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recommendedMedia) { item ->
                        MediaPosterCard(
                            media = item,
                            isArabic = isArabic,
                            isInWatchlist = watchlist.contains(item.id),
                            onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                            onClick = { onMediaClick(item) }
                        )
                    }
                }
            }

            // Section: Short Drama Series (Multi-episode)
            item {
                SectionHeader(
                    title = if (isArabic) "مسلسلات دراما قصيرة كاملة الحلقات 🎬" else "Complete Drama Series 🎬",
                    icon = {
                        Icon(
                            Icons.Default.Tv,
                            contentDescription = null,
                            tint = Color(0xFFA855F7),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(seriesList) { item ->
                        MediaPosterCard(
                            media = item,
                            isArabic = isArabic,
                            isInWatchlist = watchlist.contains(item.id),
                            onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                            onClick = { onMediaClick(item) }
                        )
                    }
                }
            }

            // Section: Action & Thriller Blockbusters
            item {
                SectionHeader(
                    title = if (isArabic) "أفلام الأكشن والإثارة والمطاردات ⚡" else "Action & High Velocity ⚡",
                    icon = {
                        Icon(
                            Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color(0xFFFF5252),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(actionFilms) { item ->
                        MediaPosterCard(
                            media = item,
                            isArabic = isArabic,
                            isInWatchlist = watchlist.contains(item.id),
                            onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                            onClick = { onMediaClick(item) }
                        )
                    }
                }
            }

            // Section: Sci-Fi & Future Worlds
            item {
                SectionHeader(
                    title = if (isArabic) "روائع الخيال العلمي والفضاء 🚀" else "Sci-Fi & Cosmic Horizons 🚀",
                    icon = {
                        Icon(
                            Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = Color(0xFF64B5F6),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(sciFiFilms) { item ->
                        MediaPosterCard(
                            media = item,
                            isArabic = isArabic,
                            isInWatchlist = watchlist.contains(item.id),
                            onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                            onClick = { onMediaClick(item) }
                        )
                    }
                }
            }

            // Section: Award-Winning Short Films & Culture
            item {
                SectionHeader(
                    title = if (isArabic) "أفلام سينمائية قصيرة وتراثية 🌟" else "Short Films & Cultural Cinema 🌟",
                    icon = {
                        Icon(
                            Icons.Default.Movie,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shortFilms) { item ->
                        MediaPosterCard(
                            media = item,
                            isArabic = isArabic,
                            isInWatchlist = watchlist.contains(item.id),
                            onToggleWatchlist = { viewModel.toggleWatchlist(item.id) },
                            onClick = { onMediaClick(item) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    icon: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
