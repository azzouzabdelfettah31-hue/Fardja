package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.ui.MainViewModel
import com.example.ui.components.CinemaGold
import com.example.ui.components.CinemaRed
import com.example.ui.components.DarkCardBg
import com.example.ui.components.TextMuted

@Composable
fun NotificationsScreen(
    viewModel: MainViewModel,
    onMediaClick: (MediaItem) -> Unit
) {
    val notifications by viewModel.notifications.collectAsState()
    val allMedia by viewModel.allMedia.collectAsState()
    val user by viewModel.userAccount.collectAsState()
    val isArabic = user.selectedLanguage == "ar"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A090E))
            .padding(16.dp)
            .testTag("notifications_screen_root")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = CinemaRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isArabic) "الإشعارات والتحديثات" else "Notifications & Updates",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Surface(
                color = Color(0x33E50914),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = if (isArabic) "${notifications.count { it.isUnread }} جديدة" else "${notifications.count { it.isUnread }} new",
                    color = CinemaRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(notifications) { notif ->
                val targetMedia = allMedia.find { it.id == notif.targetMediaId }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.markNotificationAsRead(notif.id)
                            targetMedia?.let { onMediaClick(it) }
                        }
                        .testTag("notif_card_${notif.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (notif.isUnread) Color(0xFF1E172B) else DarkCardBg
                    ),
                    border = if (notif.isUnread) androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FF2E55)) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (notif.type == "RELEASE") CinemaRed.copy(alpha = 0.2f) else CinemaGold.copy(alpha = 0.2f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    if (notif.type == "RELEASE") Icons.Default.Movie else Icons.Default.LocalOffer,
                                    contentDescription = null,
                                    tint = if (notif.type == "RELEASE") CinemaRed else CinemaGold,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isArabic) notif.titleAr else notif.titleEn,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                if (notif.isUnread) {
                                    Surface(
                                        shape = CircleShape,
                                        color = CinemaRed,
                                        modifier = Modifier.size(7.dp)
                                    ) {}
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = if (isArabic) notif.bodyAr else notif.bodyEn,
                                color = Color(0xFFD4D0DE),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (isArabic) notif.timeAgoAr else notif.timeAgoEn,
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
