package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.firebase.FirebaseSyncManager
import com.example.ui.MainViewModel
import com.example.ui.components.CinemaGold
import com.example.ui.components.CinemaRed
import com.example.ui.components.DarkCardBg
import com.example.ui.components.DarkSurface
import com.example.ui.components.TextMuted

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    onUpgradeClick: () -> Unit
) {
    val user by viewModel.userAccount.collectAsState()
    val syncState by viewModel.syncManager.syncState.collectAsState()
    val lastSync by viewModel.syncManager.lastSyncTimestamp.collectAsState()
    val encryptionKey by viewModel.syncManager.encryptionFingerprint.collectAsState()
    val isArabic = user.selectedLanguage == "ar"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A090E))
            .testTag("profile_screen_root"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // User Profile Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (user.isVip) CinemaGold else CinemaRed,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user.displayName,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (user.isVip) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = CinemaGold,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "VIP GOLD",
                                        color = Color.Black,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = user.email,
                            color = TextMuted,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "${if (isArabic) "الاشتراك:" else "Plan:"} ${user.vipPlanName} • ${user.vipExpiry}",
                            color = if (user.isVip) CinemaGold else Color(0xFFAFA7BD),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CinemaRed,
                                modifier = Modifier
                                    .clickable { viewModel.showAuthSheet(true) }
                                    .testTag("open_auth_sheet_btn")
                            ) {
                                Text(
                                    text = if (isArabic) "تسجيل الدخول / تبديل الحساب" else "Sign In / Switch",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF231F30),
                                modifier = Modifier
                                    .clickable { viewModel.signOut() }
                                    .testTag("sign_out_btn")
                            ) {
                                Text(
                                    text = if (isArabic) "تسجيل الخروج" else "Sign Out",
                                    color = Color(0xFFFF8B8B),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // VIP Subscription Action Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                border = androidx.compose.foundation.BorderStroke(1.dp, CinemaGold.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (user.isVip) {
                                    if (isArabic) "عضوية VIP الذهبية مفعلة" else "Gold VIP Active"
                                } else {
                                    if (isArabic) "ترقية الحساب إلى VIP" else "Upgrade to VIP"
                                },
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (user.isVip) {
                                    if (isArabic) "مشاهدة بلا إعلانات بجودة 4K" else "4K Ad-Free Streaming"
                                } else {
                                    if (isArabic) "تخلص من الإعلانات وحمّل بحرية" else "No ads, unlimited downloads"
                                },
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Button(
                        onClick = onUpgradeClick,
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaGold),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("profile_upgrade_btn")
                    ) {
                        Text(
                            text = if (user.isVip) {
                                if (isArabic) "إدارة" else "Manage"
                            } else {
                                if (isArabic) "اشترك الآن" else "Join VIP"
                            },
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Firebase Cloud Synchronization Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = Color(0xFF4285F4),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) "مزامنة سحابة Firebase Cloud" else "Firebase Cloud Sync",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (syncState == FirebaseSyncManager.SyncState.SYNCING) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color(0xFF4285F4),
                                strokeWidth = 2.dp
                            )
                        } else {
                            IconButton(
                                onClick = { viewModel.triggerCloudSync() },
                                modifier = Modifier.size(28.dp).testTag("sync_now_btn")
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "مزامنة الآن",
                                    tint = Color(0xFF4285F4),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${if (isArabic) "المشروع المتصل:" else "Connected Project:"} ${user.cloudProjectId} (ID: 667318653940)",
                        color = Color(0xFFB5ADC7),
                        fontSize = 11.sp
                    )
                    Text(
                        text = "${if (isArabic) "آخر مزامنة عبر الأجهزة:" else "Last Synced:"} $lastSync",
                        color = TextMuted,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Encryption Token
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF13101C), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = null,
                            tint = Color(0xFF46D369),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = encryptionKey,
                            color = Color(0xFF46D369),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Night Mode Eye Comfort (الوضع الليلي المريح للعين)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.DarkMode,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isArabic) "الوضع الليلي المريح للعين" else "Eye Comfort Night Mode",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) "فلترة الضوء الأزرق وإضاءة دافئة للقراءة والمشاهدة في الظلام" else "Warm eye-safe palette for night streaming",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = user.isEyeComfortMode,
                        onCheckedChange = { viewModel.toggleEyeComfort() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CinemaGold,
                            checkedTrackColor = Color(0x66FFB800)
                        ),
                        modifier = Modifier.testTag("eye_comfort_switch")
                    )
                }
            }
        }

        // Language Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Language,
                            contentDescription = null,
                            tint = Color(0xFF64B5F6),
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isArabic) "لغة التطبيق" else "App Language",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) "العربية (الافتراضية)" else "English",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (user.selectedLanguage == "ar") CinemaRed else Color(0xFF221C30),
                            modifier = Modifier
                                .clickable { viewModel.setLanguage("ar") }
                                .padding(end = 6.dp)
                                .testTag("lang_ar_btn")
                        ) {
                            Text(
                                text = "العربية",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (user.selectedLanguage == "en") CinemaRed else Color(0xFF221C30),
                            modifier = Modifier
                                .clickable { viewModel.setLanguage("en") }
                                .testTag("lang_en_btn")
                        ) {
                            Text(
                                text = "English",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Test Push Notification Trigger
        item {
            OutlinedButton(
                onClick = {
                    viewModel.triggerSystemNotification(
                        title = "🎬 إصدار دراما جديد متوفر الآن!",
                        body = "تمت إضافة حلقة جديدة من مسلسل مطاردة الظلال. شاهدها الآن بدقة 4K!"
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("test_notification_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Icon(
                    Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = CinemaRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isArabic) "إرسال إشعار فوري تجريبي للمشاهد" else "Trigger Test Instant Push Notification",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
