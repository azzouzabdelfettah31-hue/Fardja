package com.example.ui

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirebaseSyncManager
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.model.CommentItem
import com.example.data.model.Episode
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.data.model.NotificationModel
import com.example.data.model.SubscriptionPlan
import com.example.data.model.SupportMessage
import com.example.data.model.UserAccount
import com.example.data.repository.RealMediaRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RealMediaRepository()
    private val database = AppDatabase.getDatabase(application)
    private val downloadDao = database.downloadDao()
    val syncManager = FirebaseSyncManager(application)
    val authManager = FirebaseAuthManager(application, viewModelScope)

    // Media Items
    val allMedia = repository.mediaItems
    val allPlans: List<SubscriptionPlan> = repository.getPlans()

    // Auth Sheet State
    private val _isShowingAuthSheet = MutableStateFlow(false)
    val isShowingAuthSheet = _isShowingAuthSheet.asStateFlow()

    // Active Tab in App Navigation
    // 0: Home, 1: Explore / Search, 2: Downloads, 3: Support, 4: Profile
    private val _selectedNavIndex = MutableStateFlow(0)
    val selectedNavIndex = _selectedNavIndex.asStateFlow()

    // Selected Media for Player / Details
    private val _selectedMedia = MutableStateFlow<MediaItem?>(null)
    val selectedMedia = _selectedMedia.asStateFlow()

    // Current Playing Episode (if series)
    private val _selectedEpisode = MutableStateFlow<Episode?>(null)
    val selectedEpisode = _selectedEpisode.asStateFlow()

    // Watchlist / Favorites (Media IDs)
    private val _watchlistIds = MutableStateFlow<Set<String>>(setOf("media_tears_of_steel", "media_series_shadows"))
    val watchlistIds = _watchlistIds.asStateFlow()

    // Watched History
    private val _historyIds = MutableStateFlow<List<String>>(listOf("media_sintel", "media_big_buck_bunny"))
    val historyIds = _historyIds.asStateFlow()

    // User Profile & VIP Status
    private val _userAccount = MutableStateFlow(UserAccount())
    val userAccount = _userAccount.asStateFlow()

    // Search query & active category filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("الكل")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _minimumRatingFilter = MutableStateFlow(0.0)
    val minimumRatingFilter = _minimumRatingFilter.asStateFlow()

    // Offline Downloads from Room DB
    val offlineDownloads = downloadDao.getAllDownloads().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Ad State
    private val _isShowingAd = MutableStateFlow(false)
    val isShowingAd = _isShowingAd.asStateFlow()

    private val _adCountdown = MutableStateFlow(5)
    val adCountdown = _adCountdown.asStateFlow()

    private val _isShowingSubscriptionSheet = MutableStateFlow(false)
    val isShowingSubscriptionSheet = _isShowingSubscriptionSheet.asStateFlow()

    // Live Technical Support Chat Messages
    private val _supportMessages = MutableStateFlow<List<SupportMessage>>(listOf(
        SupportMessage(
            id = "msg_1",
            senderName = "فريق دعم دراما وموفيز",
            text = "مرحباً بك في منصة دراما وموفيز (فارجة)! كيف يمكننا مساعدتك اليوم؟ نرحب بجميع استفساراتك حول البث، الاشتراكات والتحميل.",
            isUser = false,
            timestamp = "14:20"
        )
    ))
    val supportMessages = _supportMessages.asStateFlow()

    // Notifications
    val notifications = repository.notifications

    // Video Player state
    private val _isPlaying = MutableStateFlow(true)
    val isPlaying = _isPlaying.asStateFlow()

    private val _playbackQuality = MutableStateFlow("1080p FHD")
    val playbackQuality = _playbackQuality.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted = _isMuted.asStateFlow()

    init {
        createNotificationChannel()
        viewModelScope.launch {
            authManager.currentUser.collect { _ ->
                _userAccount.value = authManager.toUserAccount(
                    currentPlanIsVip = _userAccount.value.isVip,
                    language = _userAccount.value.selectedLanguage,
                    eyeComfort = _userAccount.value.isEyeComfortMode
                )
            }
        }
        viewModelScope.launch {
            authManager.customProfile.collect { _ ->
                _userAccount.value = authManager.toUserAccount(
                    currentPlanIsVip = _userAccount.value.isVip,
                    language = _userAccount.value.selectedLanguage,
                    eyeComfort = _userAccount.value.isEyeComfortMode
                )
            }
        }
    }

    fun showAuthSheet(show: Boolean) {
        _isShowingAuthSheet.value = show
    }

    fun signOut() {
        authManager.signOut()
        _userAccount.value = authManager.toUserAccount(
            currentPlanIsVip = false,
            language = _userAccount.value.selectedLanguage,
            eyeComfort = _userAccount.value.isEyeComfortMode
        )
    }

    fun setNavIndex(index: Int) {
        _selectedNavIndex.value = index
    }

    fun openMedia(media: MediaItem, episode: Episode? = null) {
        _selectedMedia.value = media
        _selectedEpisode.value = episode ?: media.episodes.firstOrNull()

        // Track in history
        if (!_historyIds.value.contains(media.id)) {
            _historyIds.value = listOf(media.id) + _historyIds.value
        }

        // Check if user is free, trigger occasional short ad
        if (!_userAccount.value.isVip) {
            triggerAdBreak()
        }
    }

    fun closePlayer() {
        _selectedMedia.value = null
        _selectedEpisode.value = null
        _isShowingAd.value = false
    }

    fun selectEpisode(episode: Episode) {
        _selectedEpisode.value = episode
        if (!_userAccount.value.isVip) {
            triggerAdBreak()
        }
    }

    private fun triggerAdBreak() {
        _isShowingAd.value = true
        _adCountdown.value = 5
        viewModelScope.launch {
            while (_adCountdown.value > 0 && _isShowingAd.value) {
                delay(1000)
                _adCountdown.value -= 1
            }
        }
    }

    fun skipAd() {
        _isShowingAd.value = false
    }

    fun toggleWatchlist(mediaId: String) {
        val current = _watchlistIds.value.toMutableSet()
        if (current.contains(mediaId)) {
            current.remove(mediaId)
        } else {
            current.add(mediaId)
        }
        _watchlistIds.value = current
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setMinimumRating(rating: Double) {
        _minimumRatingFilter.value = rating
    }

    // Toggle Eye Comfort (Night Mode Warm Tint)
    fun toggleEyeComfort() {
        _userAccount.value = _userAccount.value.copy(
            isEyeComfortMode = !_userAccount.value.isEyeComfortMode
        )
    }

    // Switch Language (Arabic / English)
    fun setLanguage(lang: String) {
        _userAccount.value = _userAccount.value.copy(
            selectedLanguage = lang
        )
    }

    fun toggleVipStatus() {
        val newStatus = !_userAccount.value.isVip
        _userAccount.value = _userAccount.value.copy(
            isVip = newStatus,
            vipPlanName = if (newStatus) "VIP السنوي الذهبي" else "الحساب المجاني",
            vipExpiry = if (newStatus) "نشط حتى 2027-09-07" else "غير مفعل"
        )
        if (newStatus) {
            _isShowingAd.value = false
            triggerSystemNotification(
                title = "🎉 تم تفعيل اشتراك VIP بنجاح!",
                body = "استمتع الآن بمشاهدة جميع الأفلام والمسلسلات بدون إعلانات وبجودة 4K فائقة."
            )
        }
    }

    fun activateCoupon(code: String): Boolean {
        val clean = code.trim().uppercase()
        if (clean == "FARDJA2026" || clean == "VIPFREE" || clean == "DRAMA") {
            _userAccount.value = _userAccount.value.copy(
                isVip = true,
                vipPlanName = "VIP سنوي (كوبون $clean)",
                vipExpiry = "نشط حتى 2027-12-31"
            )
            _isShowingAd.value = false
            triggerSystemNotification(
                title = "✨ تم تفعيل كود الخصم!",
                body = "تمت ترقية حسابك إلى باقة VIP بنجاح مجاناً!"
            )
            return true
        }
        return false
    }

    fun showSubscriptionSheet(show: Boolean) {
        _isShowingSubscriptionSheet.value = show
    }

    fun markNotificationAsRead(id: String) {
        repository.markNotificationAsRead(id)
    }

    // Offline Download Feature with Room
    fun toggleDownload(media: MediaItem) {
        viewModelScope.launch {
            val existing = downloadDao.getDownloadById(media.id)
            if (existing != null) {
                downloadDao.deleteDownload(media.id)
            } else {
                val download = DownloadEntity(
                    id = media.id,
                    titleAr = media.titleAr,
                    titleEn = media.titleEn,
                    mediaType = media.type.name,
                    streamUrl = media.videoStreamUrl,
                    localUri = media.videoStreamUrl,
                    durationText = media.durationText,
                    posterUrl = media.posterUrl,
                    fileSizeMb = 345.5,
                    isCompleted = true
                )
                downloadDao.insertDownload(download)
                triggerSystemNotification(
                    title = "📥 تم تنزيل المحتوى بنجاح",
                    body = "${media.titleAr} جاهز الآن للمشاهدة بدون إنترنت من قائمة تنزيلاتي."
                )
            }
        }
    }

    fun removeDownload(id: String) {
        viewModelScope.launch {
            downloadDao.deleteDownload(id)
        }
    }

    // Submit Review & Comment
    fun submitReview(mediaId: String, text: String, rating: Float) {
        if (text.isBlank()) return
        val comment = CommentItem(
            id = UUID.randomUUID().toString(),
            authorName = _userAccount.value.displayName,
            avatarUrl = "",
            text = text,
            rating = rating,
            timestamp = "الآن",
            isVip = _userAccount.value.isVip,
            likes = 0
        )
        repository.addComment(mediaId, comment)
    }

    // Support Chat
    fun sendSupportMessage(userText: String) {
        if (userText.isBlank()) return
        val userMsg = SupportMessage(
            id = UUID.randomUUID().toString(),
            senderName = _userAccount.value.displayName,
            text = userText,
            isUser = true,
            timestamp = "الآن"
        )
        _supportMessages.value = _supportMessages.value + userMsg

        // Auto-reply logic based on keywords
        viewModelScope.launch {
            delay(1000)
            val replyText = when {
                userText.contains("اشتراك") || userText.contains("vip") || userText.contains("دفع") ->
                    "يمكنك تفعيل اشتراك VIP فوراً عبر بطاقات الدفع أو تفعيل الكود FARDJA2026 للحصول على اشتراك هدية مجاناً!"
                userText.contains("تحميل") || userText.contains("أوفلاين") || userText.contains("تنزيل") ->
                    "يمكنك تحميل أي فيلم أو حلقة مسلسل بالضغط على زر 'تحميل' وسيتوفر مباشرة في شاشة تنزيلاتي لمشاهدته دون اتصال بالإنترنت."
                userText.contains("مشكلة") || userText.contains("تقطيع") || userText.contains("جودة") ->
                    "خوادم المنصة تدعم الجودة التكيفية التلقائية. تأكد من ثبات اتصال الإنترنت أو اختر جودة 720p لتحميل أسرع."
                else ->
                    "شكراً لتواصلك مع دعم دراما وموفيز! تم تسجيل استفسارك وسيقوم ممثل خدمة العملاء بالرد عليك فوراً خلال دقائق."
            }
            val botMsg = SupportMessage(
                id = UUID.randomUUID().toString(),
                senderName = "الدعم الفني المباشر 🟢",
                text = replyText,
                isUser = false,
                timestamp = "الآن"
            )
            _supportMessages.value = _supportMessages.value + botMsg
        }
    }

    // Firebase Cloud Sync
    fun triggerCloudSync() {
        viewModelScope.launch {
            syncManager.performCloudSync(
                user = _userAccount.value,
                watchlistIds = _watchlistIds.value,
                downloadedCount = offlineDownloads.value.size
            )
        }
    }

    // Native Android Notification Trigger
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "fardja_drama_channel",
                "Fardja Drama Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات الإصدارات الجديدة وتحديثات المسلسلات"
            }
            val manager = getApplication<Application>().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun triggerSystemNotification(title: String, body: String) {
        try {
            val context = getApplication<Application>()
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = NotificationCompat.Builder(context, "fardja_drama_channel")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            manager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (e: Exception) {
            // Permission or context fallback
        }
    }

    // Smart Recommendations Algorithm:
    // Calculates score based on user preferred genres, history matches, and rating weight
    fun getRecommendedMedia(): List<MediaItem> {
        val userGenres = _userAccount.value.favoriteGenres
        val watched = _historyIds.value.toSet()

        return allMedia.value
            .filter { !watched.contains(it.id) }
            .sortedByDescending { media ->
                var score = media.rating * 10
                if (userGenres.any { genre -> media.genreAr.contains(genre) }) {
                    score += 30
                }
                if (media.isTrending) score += 15
                score
            }
            .ifEmpty { allMedia.value }
    }
}
