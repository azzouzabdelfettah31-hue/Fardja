package com.example.ui.screens

import android.app.Activity
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.TextButton
import com.example.ui.ads.AdMobBanner
import com.example.ui.ads.AdMobManager
import com.example.ui.components.EpisodeGridSelector
import com.example.ui.components.ExoVideoPlayer
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.CommentItem
import com.example.data.model.Episode
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.ui.MainViewModel
import com.example.ui.components.CinemaGold
import com.example.ui.components.CinemaRed
import com.example.ui.components.DarkCardBg
import com.example.ui.components.DarkSurface
import com.example.ui.components.EpisodeItemCard
import com.example.ui.components.TextMuted

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    viewModel: MainViewModel,
    media: MediaItem,
    selectedEpisode: Episode?,
    onBackClick: () -> Unit,
    onUpgradeVipClick: () -> Unit
) {
    val context = LocalContext.current
    val user by viewModel.userAccount.collectAsState()
    val isArabic = user.selectedLanguage == "ar"
    val watchlist by viewModel.watchlistIds.collectAsState()
    val isInWatchlist = watchlist.contains(media.id)

    val downloads by viewModel.offlineDownloads.collectAsState()
    val isDownloaded = downloads.any { it.id == media.id }

    val isShowingAd by viewModel.isShowingAd.collectAsState()
    val adCountdown by viewModel.adCountdown.collectAsState()

    // Comments for this media
    val commentsList by viewModel.allMedia.collectAsState()
    val comments by viewModel.syncManager.syncState.collectAsState()

    var newReviewText by remember { mutableStateOf("") }
    var selectedRating by remember { mutableStateOf(5.0f) }

    val activity = context as? Activity
    var showEpisodesSheet by remember { mutableStateOf(false) }
    var showUnlockAdDialog by remember { mutableStateOf<Episode?>(null) }

    val activeStreamUrl = selectedEpisode?.videoUrl ?: media.videoStreamUrl

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A090E))
            .testTag("player_screen_root")
    ) {
        // High-Performance Modern ExoPlayer Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
            ) {
                ExoVideoPlayer(
                    videoUrl = activeStreamUrl,
                    title = if (isArabic) media.titleAr else media.titleEn,
                    episodeSubtitle = selectedEpisode?.let { if (isArabic) it.titleAr else it.titleEn },
                    isArabic = isArabic,
                    isVip = user.isVip,
                    isVertical = media.isVerticalFormat,
                    onBackClick = onBackClick,
                    onNextEpisodeClick = {
                        val currentNum = selectedEpisode?.episodeNumber ?: 1
                        val nextEp = media.episodes.find { it.episodeNumber == currentNum + 1 }
                        if (nextEp != null) {
                            if (nextEp.isVipOnly && !user.isVip) {
                                showUnlockAdDialog = nextEp
                            } else {
                                viewModel.selectEpisode(nextEp)
                            }
                        }
                    },
                    onOpenEpisodesSheet = if (media.episodes.isNotEmpty()) {
                        { showEpisodesSheet = true }
                    } else null
                )
            }
        }

        // Details Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Title
                Text(
                    text = if (selectedEpisode != null) {
                        "${if (isArabic) media.titleAr else media.titleEn} - ${if (isArabic) selectedEpisode.titleAr else selectedEpisode.titleEn}"
                    } else {
                        if (isArabic) media.titleAr else media.titleEn
                    },
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Meta Info Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color(0x3346D369),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "${media.matchPercentage}% تطابق",
                            color = Color(0xFF46D369),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "${media.releaseYear}",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        color = Color(0x22FFFFFF),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = media.ageRating,
                            color = Color.White,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = media.durationText,
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = CinemaGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${media.rating}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Bar: Watchlist, Download, Share, Rate
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { viewModel.toggleWatchlist(media.id) }
                            .testTag("action_watchlist_btn")
                    ) {
                        Icon(
                            if (isInWatchlist) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "قائمتي",
                            tint = if (isInWatchlist) CinemaGold else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isInWatchlist) {
                                if (isArabic) "في قائمتي" else "Added"
                            } else {
                                if (isArabic) "قائمتي" else "Watchlist"
                            },
                            color = if (isInWatchlist) CinemaGold else TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { viewModel.toggleDownload(media) }
                            .testTag("action_download_btn")
                    ) {
                        Icon(
                            if (isDownloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                            contentDescription = "تنزيل أوفلاين",
                            tint = if (isDownloaded) Color(0xFF46D369) else Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isDownloaded) {
                                if (isArabic) "تم التنزيل" else "Downloaded"
                            } else {
                                if (isArabic) "تنزيل أوفلاين" else "Download"
                            },
                            color = if (isDownloaded) Color(0xFF46D369) else TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable {
                                viewModel.triggerSystemNotification(
                                    title = "تم نسخ رابط المشاركة",
                                    body = "شارك ${media.titleAr} مع أصدقائك عبر وسائل التواصل الاجتماعي."
                                )
                            }
                            .testTag("action_share_btn")
                    ) {
                        Icon(
                            Icons.Default.Share,
                            contentDescription = "مشاركة",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) "مشاركة" else "Share",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { onUpgradeVipClick() }
                            .testTag("action_vip_perk_btn")
                    ) {
                        Icon(
                            Icons.Default.WorkspacePremium,
                            contentDescription = "VIP",
                            tint = CinemaGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) "مزايا VIP" else "VIP Perks",
                            color = CinemaGold,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Description
                Text(
                    text = if (isArabic) media.descriptionAr else media.descriptionEn,
                    color = Color(0xFFD4D0DE),
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Cast & Director
                Text(
                    text = "${if (isArabic) "بطولة:" else "Cast:"} ${media.cast.joinToString("، ")}",
                    color = TextMuted,
                    fontSize = 12.sp
                )
                Text(
                    text = "${if (isArabic) "إخراج:" else "Director:"} ${media.director}",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }

        // Episodes Section (All Episodes / Tous les épisodes Grid)
        if (media.episodes.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    EpisodeGridSelector(
                        episodes = media.episodes,
                        currentEpisode = selectedEpisode,
                        isArabic = isArabic,
                        isVip = user.isVip,
                        onEpisodeSelected = { ep ->
                            if (ep.isVipOnly && !user.isVip) {
                                showUnlockAdDialog = ep
                            } else {
                                viewModel.selectEpisode(ep)
                            }
                        }
                    )
                }
            }
        }

        // Real Google AdMob Banner for Non-VIP Users
        if (!user.isVip) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = if (isArabic) "إعلان مدعوم • تخلص من الإعلانات مع VIP" else "Sponsored • Go Ad-Free with VIP",
                        color = Color(0xFF6B7280),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    AdMobBanner()
                }
            }
        }

        // Interactive Ratings & Reviews Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = if (isArabic) "تقييمات وآراء المشاهدين ⭐" else "Ratings & Reviews ⭐",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Post New Review Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCardBg)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isArabic) "أضف تقييمك الخاص" else "Add Your Review",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Star Rating Selector
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            for (star in 1..5) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "$star نجوم",
                                    tint = if (star <= selectedRating) CinemaGold else Color.Gray,
                                    modifier = Modifier
                                        .size(26.dp)
                                        .clickable { selectedRating = star.toFloat() }
                                        .padding(2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${selectedRating.toInt()}/5",
                                color = CinemaGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newReviewText,
                            onValueChange = { newReviewText = it },
                            placeholder = {
                                Text(
                                    text = if (isArabic) "ما هو رأيك في هذا العمل؟ شارك انطباعك..." else "What did you think of this movie/series?...",
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("review_input_field"),
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = CinemaRed,
                                unfocusedBorderColor = Color(0x33FFFFFF)
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                viewModel.submitReview(media.id, newReviewText, selectedRating)
                                newReviewText = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CinemaRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .align(Alignment.End)
                                .height(36.dp)
                                .testTag("submit_review_btn"),
                            enabled = newReviewText.isNotBlank()
                        ) {
                            Icon(
                                Icons.Default.Send,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isArabic) "نشر التقييم" else "Post",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Default Community Reviews
                val sampleReviews = listOf(
                    CommentItem(
                        id = "rev_1",
                        authorName = "طارق الحكيم",
                        text = "عمل استثنائي وإخراج سينمائي مبهر! تسلسل المشاهد السريعة مع المؤثرات الصوتية مذهل جداً.",
                        rating = 5.0f,
                        timestamp = "منذ ساعتين",
                        isVip = true,
                        likes = 19
                    ),
                    CommentItem(
                        id = "rev_2",
                        authorName = "ياسمين نور",
                        text = "تطبيق فارجة مريح جداً للعين خصوصاً في الليل، والفيلم ممتع ويستحق المشاهدة مع العائلة.",
                        rating = 4.8f,
                        timestamp = "منذ 6 ساعات",
                        isVip = false,
                        likes = 11
                    )
                )

                sampleReviews.forEach { comment ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (comment.isVip) CinemaGold else CinemaRed,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = comment.authorName.take(1),
                                                color = Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Text(
                                        text = comment.authorName,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    if (comment.isVip) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = CinemaGold,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "VIP",
                                                color = Color.Black,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = comment.timestamp,
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                for (i in 1..5) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (i <= comment.rating) CinemaGold else Color.Gray,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = comment.text,
                                color = Color(0xFFD4D0DE),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Episodes Modal BottomSheet (accessible from player controls)
    if (showEpisodesSheet && media.episodes.isNotEmpty()) {
        ModalBottomSheet(
            onDismissRequest = { showEpisodesSheet = false },
            containerColor = Color(0xFF0F1216)
        ) {
            EpisodeGridSelector(
                episodes = media.episodes,
                currentEpisode = selectedEpisode,
                isArabic = isArabic,
                isVip = user.isVip,
                onCloseClick = { showEpisodesSheet = false },
                onEpisodeSelected = { ep ->
                    showEpisodesSheet = false
                    if (ep.isVipOnly && !user.isVip) {
                        showUnlockAdDialog = ep
                    } else {
                        viewModel.selectEpisode(ep)
                    }
                }
            )
        }
    }

    // Rewarded Ad Unlock Dialog for Locked Episodes
    if (showUnlockAdDialog != null) {
        val targetEpisode = showUnlockAdDialog!!
        AlertDialog(
            onDismissRequest = { showUnlockAdDialog = null },
            containerColor = Color(0xFF1B1D28),
            title = {
                Text(
                    text = if (isArabic) "فتح الحلقة ${targetEpisode.episodeNumber} 🎬" else "Unlock Episode ${targetEpisode.episodeNumber}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isArabic)
                        "هذه الحلقة مخصصة لمشتركي VIP أو يمكنك فتحها مجاناً الآن بمشاهدة إعلان فيديو قصير."
                    else
                        "This episode is VIP-only or can be unlocked for free by watching a short video ad.",
                    color = Color(0xFFD4D0DE),
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val epToPlay = targetEpisode
                        showUnlockAdDialog = null
                        if (activity != null) {
                            AdMobManager.showRewardedAd(
                                activity = activity,
                                onRewardEarned = {
                                    viewModel.selectEpisode(epToPlay)
                                }
                            )
                        } else {
                            viewModel.selectEpisode(epToPlay)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B488))
                ) {
                    Text(
                        text = if (isArabic) "مشاهدة إعلان لفتح الحلقة 🎁" else "Watch Ad to Unlock",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showUnlockAdDialog = null
                        onUpgradeVipClick()
                    }
                ) {
                    Text(
                        text = if (isArabic) "ترقية VIP بدون إعلانات ⭐" else "Upgrade VIP",
                        color = CinemaGold,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }
}
