package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CinemaRedPrimary = Color(0xFFE50914)
val CinemaGoldAccent = Color(0xFFFFB800)
val DarkBackground = Color(0xFF0A090E)
val DarkCardSurface = Color(0xFF14121C)
val TextLight = Color(0xFFF1EFF5)
val TextMutedColor = Color(0xFF9E9AA8)
val WarmTintOverlay = Color(0x22FFA726)

