package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Episode

/**
 * Episode grid selector matching the Short Drama (DramaBox / ReelShort / KissKH) screenshot style:
 * Header with "Tous les épisodes / جميع الحلقات" and numeric tiles (01, 02, 03... 19).
 * Active episode highlighted in teal/cyan with bright text.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EpisodeGridSelector(
    episodes: List<Episode>,
    currentEpisode: Episode?,
    isArabic: Boolean = true,
    isVip: Boolean = false,
    onEpisodeSelected: (Episode) -> Unit,
    onCloseClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val activeNumber = currentEpisode?.episodeNumber ?: 1

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0F1216))
            .padding(16.dp)
            .testTag("episode_grid_selector")
    ) {
        // Header Row: Close button and Title
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onCloseClick != null) {
                IconButton(
                    onClick = onCloseClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("close_episodes_grid_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color(0xFFC0C7D0)
                    )
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.OndemandVideo,
                        contentDescription = null,
                        tint = Color(0xFF00B488),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "الحلقة الحالية: $activeNumber / ${episodes.size}" else "Current: Ep $activeNumber / ${episodes.size}",
                        color = Color(0xFF8A93A0),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Text(
                text = if (isArabic) "جميع الحلقات (${episodes.size})" else "Tous les épisodes (${episodes.size})",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.testTag("all_episodes_title")
            )
        }

        // 6-Column Responsive Flow Grid of Episode Numbers
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 6
        ) {
            episodes.forEach { episode ->
                val isSelected = episode.episodeNumber == activeNumber
                val isLocked = episode.isVipOnly && !isVip

                EpisodeNumberTile(
                    episode = episode,
                    isSelected = isSelected,
                    isLocked = isLocked,
                    onClick = {
                        onEpisodeSelected(episode)
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun EpisodeNumberTile(
    episode: Episode,
    isSelected: Boolean,
    isLocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedNumber = String.format("%02d", episode.episodeNumber)

    // Tile Colors matching user screenshot:
    // Active: Teal/Cyan dark background (#0E4A44) with bright teal green text (#00E676 / #3DDB84)
    // Inactive: Dark slate background (#1A2027) with slate white text (#C8D1DC)
    val tileBg = when {
        isSelected -> Color(0xFF0D4740)
        isLocked -> Color(0xFF14181E)
        else -> Color(0xFF1B222B)
    }

    val textColor = when {
        isSelected -> Color(0xFF00E676)
        isLocked -> Color(0xFF6B7280)
        else -> Color(0xFFC7D0DB)
    }

    val borderColor = if (isSelected) Color(0xFF00B488) else Color(0x1AFFFFFF)

    Surface(
        modifier = modifier
            .aspectRatio(1.15f)
            .clip(RoundedCornerShape(8.dp))
            .border(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .testTag("episode_tile_${episode.episodeNumber}"),
        color = tileBg,
        shape = RoundedCornerShape(8.dp)
    ) {
        Box(
            modifier = Modifier.padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = formattedNumber,
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                if (isLocked) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "مغلق",
                        tint = Color(0xFFFFA000),
                        modifier = Modifier.size(10.dp)
                    )
                } else if (isSelected) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .size(4.dp)
                            .background(Color(0xFF00E676), CircleShape)
                    )
                }
            }
        }
    }
}
