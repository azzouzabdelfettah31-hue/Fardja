package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.example.ui.MainViewModel
import com.example.ui.ads.AdMobManager
import com.example.ui.components.CinemaGold
import com.example.ui.components.CinemaRed
import com.example.ui.components.DarkCardBg
import com.example.ui.screens.AuthModal
import com.example.ui.screens.DownloadsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveSupportScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SubscriptionModal
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Initialize AdMob safely in the background
        AdMobManager.initialize(applicationContext)
        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    var isSplashLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(1200)
        isSplashLoading = false
    }

    val selectedNavIndex by viewModel.selectedNavIndex.collectAsState()
    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val selectedEpisode by viewModel.selectedEpisode.collectAsState()
    val user by viewModel.userAccount.collectAsState()
    val isShowingSubscriptionSheet by viewModel.isShowingSubscriptionSheet.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val unreadNotifs = notifications.count { it.isUnread }

    val isArabic = user.selectedLanguage == "ar"
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    if (isSplashLoading) {
        AppSplashScreen(
            isArabic = isArabic,
            onDismiss = { isSplashLoading = false }
        )
        return
    }

    // Handle back button when player is open or not on home tab
    BackHandler(enabled = selectedMedia != null || selectedNavIndex != 0) {
        if (selectedMedia != null) {
            viewModel.closePlayer()
        } else {
            viewModel.setNavIndex(0)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0A090E)),
                topBar = {
                    if (selectedMedia == null) {
                        AppTopBar(
                            isArabic = isArabic,
                            isVip = user.isVip,
                            unreadCount = unreadNotifs,
                            onUpgradeClick = { viewModel.showSubscriptionSheet(true) },
                            onNotificationClick = { viewModel.setNavIndex(5) } // Index 5: Notifications
                        )
                    }
                },
                bottomBar = {
                    if (selectedMedia == null) {
                        AppBottomNavBar(
                            selectedIndex = selectedNavIndex,
                            isArabic = isArabic,
                            onSelectTab = { index -> viewModel.setNavIndex(index) }
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (selectedNavIndex) {
                        0 -> HomeScreen(
                            viewModel = viewModel,
                            onMediaClick = { item -> viewModel.openMedia(item) },
                            onUpgradeClick = { viewModel.showSubscriptionSheet(true) }
                        )
                        1 -> SearchScreen(
                            viewModel = viewModel,
                            onMediaClick = { item -> viewModel.openMedia(item) }
                        )
                        2 -> DownloadsScreen(
                            viewModel = viewModel,
                            onPlayOffline = { item -> viewModel.openMedia(item) },
                            onBrowseClick = { viewModel.setNavIndex(0) }
                        )
                        3 -> LiveSupportScreen(
                            viewModel = viewModel
                        )
                        4 -> ProfileScreen(
                            viewModel = viewModel,
                            onUpgradeClick = { viewModel.showSubscriptionSheet(true) }
                        )
                        5 -> NotificationsScreen(
                            viewModel = viewModel,
                            onMediaClick = { item ->
                                viewModel.openMedia(item)
                            }
                        )
                    }
                }
            }

            // Dedicated Player Screen Overlay
            if (selectedMedia != null) {
                PlayerScreen(
                    viewModel = viewModel,
                    media = selectedMedia!!,
                    selectedEpisode = selectedEpisode,
                    onBackClick = { viewModel.closePlayer() },
                    onUpgradeVipClick = { viewModel.showSubscriptionSheet(true) }
                )
            }

            // Subscription Modal
            if (isShowingSubscriptionSheet) {
                SubscriptionModal(
                    viewModel = viewModel,
                    onDismiss = { viewModel.showSubscriptionSheet(false) }
                )
            }

            // Authentication Modal (Firebase Auth & Google Sign-In)
            val isShowingAuthSheet by viewModel.isShowingAuthSheet.collectAsState()
            if (isShowingAuthSheet) {
                AuthModal(
                    viewModel = viewModel,
                    onDismiss = { viewModel.showAuthSheet(false) }
                )
            }

            // Eye Comfort Mode Warm Tint Overlay
            if (user.isEyeComfortMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x18FFA726))
                )
            }
        }
    }
}

@Composable
fun AppTopBar(
    isArabic: Boolean,
    isVip: Boolean,
    unreadCount: Int,
    onUpgradeClick: () -> Unit,
    onNotificationClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A090E))
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Logo & Brand Name
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.testTag("app_brand_header")
        ) {
            // Circular Logo with subtle glow halo
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(CinemaRed.copy(alpha = 0.25f), CircleShape)
                    .border(1.5.dp, CinemaRed, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = CinemaRed,
                    modifier = Modifier.size(30.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "F",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = if (isArabic) "فارجة • دراما وموفيز" else "Fardja Drama & Movies",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isArabic) "أفلام قصيرة ومسلسلات حصرية" else "Short Films & Exclusive Series",
                    color = CinemaGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Normal
                )
            }
        }

        // Action Buttons: VIP Badge & Notification Bell
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (isVip) CinemaGold else CinemaRed,
                border = BorderStroke(1.dp, if (isVip) CinemaGold else CinemaRed),
                modifier = Modifier
                    .clickable { onUpgradeClick() }
                    .testTag("topbar_vip_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = if (isVip) Color.Black else Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isVip) {
                            if (isArabic) "VIP نشط" else "VIP Active"
                        } else {
                            if (isArabic) "ترقية VIP" else "Get VIP"
                        },
                        color = if (isVip) Color.Black else Color.White,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            IconButton(
                onClick = onNotificationClick,
                modifier = Modifier.testTag("topbar_notifications_btn")
            ) {
                BadgedBox(
                    badge = {
                        if (unreadCount > 0) {
                            Badge(
                                containerColor = CinemaRed,
                                contentColor = Color.White
                            ) {
                                Text("$unreadCount")
                            }
                        }
                    }
                ) {
                    Icon(
                        Icons.Default.Notifications,
                        contentDescription = "الإشعارات",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AppBottomNavBar(
    selectedIndex: Int,
    isArabic: Boolean,
    onSelectTab: (Int) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFF0E0D14),
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .testTag("app_bottom_nav_bar")
    ) {
        val items = listOf(
            Triple(if (isArabic) "الرئيسية" else "Home", Icons.Default.Home, 0),
            Triple(if (isArabic) "استكشف" else "Explore", Icons.Default.Search, 1),
            Triple(if (isArabic) "تنزيلاتي" else "Downloads", Icons.Default.FileDownload, 2),
            Triple(if (isArabic) "الدعم" else "Support", Icons.Default.SupportAgent, 3),
            Triple(if (isArabic) "حسابي" else "Profile", Icons.Default.Person, 4)
        )

        items.forEach { (label, icon, index) ->
            val isSelected = selectedIndex == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectTab(index) },
                alwaysShowLabel = true, // Always show label as requested!
                icon = {
                    Icon(
                        icon,
                        contentDescription = label,
                        modifier = Modifier.size(25.dp) // Larger icons!
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    unselectedIconColor = Color(0xFF8E889C),
                    selectedTextColor = CinemaRed,
                    unselectedTextColor = Color(0xFF8E889C),
                    indicatorColor = CinemaRed
                ),
                modifier = Modifier.testTag("nav_tab_$index")
            )
        }
    }
}

@Composable
fun AppSplashScreen(
    isArabic: Boolean,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07060A))
            .clickable { onDismiss() }
            .testTag("app_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Glowing Ambient Emblem
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(175.dp)
            ) {
                // Soft Radiant Glow Halo Background
                Box(
                    modifier = Modifier
                        .size(175.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    CinemaRed.copy(alpha = 0.55f),
                                    CinemaRed.copy(alpha = 0.18f),
                                    Color.Transparent
                                )
                            ),
                            CircleShape
                        )
                )

                // Outer Glowing Border Ring
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .border(
                            2.dp,
                            Brush.sweepGradient(
                                listOf(CinemaRed, CinemaGold, CinemaRed)
                            ),
                            CircleShape
                        )
                        .background(Color(0x33000000), CircleShape)
                )

                // Central Circle (Enlarged Logo)
                Surface(
                    shape = CircleShape,
                    color = CinemaRed,
                    shadowElevation = 18.dp,
                    modifier = Modifier.size(106.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "F",
                            color = Color.White,
                            fontSize = 56.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            // App Name (Bold Header)
            Text(
                text = if (isArabic) "فارجة • FARDJA" else "Fardja Cinema",
                color = Color.White,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Subtitle (Normal Text)
            Text(
                text = if (isArabic) "سينما الأفلام القصيرة والمسلسلات الحصرية" else "Exclusive Drama & Short Series",
                color = CinemaGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Normal
            )

            Spacer(modifier = Modifier.height(34.dp))

            // Sleek Loading Indicator
            CircularProgressIndicator(
                color = CinemaRed,
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
