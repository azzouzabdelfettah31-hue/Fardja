package com.example

import com.example.data.model.MediaType
import com.example.data.repository.RealMediaRepository
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun realMediaRepository_hasSufficientContent() {
    val items = RealMediaRepository.getMediaList()
    assertTrue("Repository should have more than 15 media items", items.size >= 15)

    // Verify series have episodes
    val series = items.filter { it.type == MediaType.SERIES }
    assertTrue("Repository should have series", series.isNotEmpty())
    for (s in series) {
      assertTrue("Series ${s.titleAr} must have episodes", s.episodes.isNotEmpty())
      for (ep in s.episodes) {
        assertTrue("Episode URL must not be blank", ep.videoUrl.isNotBlank())
      }
    }

    // Verify movies have valid links
    val movies = items.filter { it.type == MediaType.SHORT_FILM }
    assertTrue("Repository should have short films", movies.isNotEmpty())
    for (m in movies) {
      assertTrue("Movie ${m.titleAr} must have stream URL", m.videoUrl.isNotBlank())
    }
  }
}
